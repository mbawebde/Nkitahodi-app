# Nkitahodi

A documentary network of collaboration among Ghanaian language-technology organisations, 2021–2026.

## Deploy on Vercel

1. Open [vercel.com/new](https://vercel.com/new) and sign in.
2. Choose **Upload** and select this folder (or the zip).
3. Leave the defaults: Framework **Vite**, build command `npm run build`.
4. Deploy. No environment variables are required.

The public graph is compiled from cited sources in `src/lib/sim/documented.ts`.
