import { useLab } from "@/lib/store";
import { formatNum } from "@/lib/utils";

export function MetricStrip() {
  const m = useLab((s) => s.metrics);
  const n = useLab((s) => s.world.agents.length);
  const e = useLab((s) => s.world.edges.length);

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      <Monitor k="Organisations" v={String(n)} />
      <Monitor k="Cited threads" v={String(e)} />
      <Monitor k="Clustering coefficient" v={formatNum(m.clustering, 3)} />
      <Monitor k="Average path length" v={formatNum(m.avgPath, 3)} />
    </div>
  );
}

function Monitor({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface px-3 py-3">
      <p className="text-xs text-muted">{k}</p>
      <p className="mt-1 font-display text-2xl tabular-nums text-fg">{v}</p>
    </div>
  );
}
