import { collaborationOf } from "@/lib/sim/collaboration";
import { explainCluster } from "@/lib/sim/insights";
import { useLab } from "@/lib/store";
import { formatNum } from "@/lib/utils";

export function CollaborationStats() {
  const world = useLab((s) => s.world);
  const selectedId = useLab((s) => s.selectedId);
  const global = useLab((s) => s.metrics);

  if (selectedId == null) {
    return (
      <div className="grid grid-cols-2 gap-px border-t border-border bg-border">
        <Stat k="Clustering" v={formatNum(global.clustering, 3)} hint="Whole public map" />
        <Stat k="Typical walk" v={formatNum(global.avgPath, 3)} hint="Whole public map" />
      </div>
    );
  }

  const col = collaborationOf(world, selectedId);
  const agent = world.agents.find((a) => a.id === selectedId);

  return (
    <div className="border-t border-border bg-surface px-4 py-3">
      <p className="text-[10px] uppercase tracking-wide text-muted">{agent?.name}</p>
      <div className="mt-2 grid grid-cols-2 gap-3">
        <Stat
          k="Clustering"
          v={col.clustering == null ? "n/a" : formatNum(col.clustering, 3)}
          hint="This name + its public partners"
        />
        <Stat
          k="Typical walk"
          v={col.avgPath == null ? "n/a" : formatNum(col.avgPath, 3)}
          hint="This name + its public partners"
        />
      </div>
      <p className="mt-2 text-xs leading-relaxed text-subtle">
        {explainCluster(col.clustering, col.avgPath, col.size, col.cited)}
      </p>
    </div>
  );
}

function Stat({ k, v, hint }: { k: string; v: string; hint: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wide text-muted">{k}</p>
      <p className="font-display text-2xl tabular-nums text-fg">{v}</p>
      <p className="text-[11px] text-subtle">{hint}</p>
    </div>
  );
}
