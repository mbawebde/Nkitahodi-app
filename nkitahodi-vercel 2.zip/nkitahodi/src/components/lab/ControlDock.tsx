export function ControlDock() {
  return null;
}
