/** Distinctive HELIX mark: a woven collaboration graph, not a screenshot of the data. */
export function HeroMark() {
  return (
    <div className="relative overflow-hidden border-b border-border bg-white">
      <svg
        viewBox="0 0 1400 220"
        className="block h-[132px] w-full md:h-[176px]"
        role="img"
        aria-label="Nkitahodi: a woven network of producer, intermediate, and user nodes"
      >
        <defs>
          <pattern id="paper" width="8" height="8" patternUnits="userSpaceOnUse">
            <rect width="8" height="8" fill="#ffffff" />
            <circle cx="1" cy="1" r="0.4" fill="#c4a574" opacity="0.28" />
          </pattern>
          <linearGradient id="thread" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#6b4f2a" />
            <stop offset="50%" stopColor="#c4a574" />
            <stop offset="100%" stopColor="#3d5a48" />
          </linearGradient>
        </defs>
        <rect width="1400" height="220" fill="url(#paper)" />

        <g opacity="0.9" stroke="url(#thread)" strokeWidth="1.4" fill="none">
          <path d="M80 160 C 220 40, 380 200, 520 90" />
          <path d="M520 90 C 640 20, 720 180, 860 70" />
          <path d="M860 70 C 980 10, 1080 190, 1280 80" />
          <path d="M160 50 C 300 180, 480 20, 700 150" />
          <path d="M700 150 C 860 210, 1000 40, 1220 160" />
          <path d="M240 190 C 500 80, 760 200, 1100 40" />
        </g>
        <g opacity="0.35" stroke="#7a9a7e" strokeWidth="0.8" fill="none">
          <path d="M90 70 L 200 150 L 340 40 L 480 170 L 640 55 L 800 175 L 960 48 L 1120 165 L 1280 60" />
        </g>

        {/* producers — squares */}
        <g fill="#16140f">
          <rect x="508" y="78" width="24" height="24" />
          <rect x="848" y="58" width="22" height="22" />
          <rect x="148" y="38" width="20" height="20" />
          <rect x="1268" y="68" width="20" height="20" />
        </g>
        {/* intermediates — diamonds */}
        <g fill="#c4a574">
          <path d="M700 150 l12 -12 l12 12 l-12 12 z" />
          <path d="M340 40 l10 -10 l10 10 l-10 10 z" />
        </g>
        {/* users — circles */}
        <g fill="#7a9a7e">
          <circle cx="240" cy="190" r="9" />
          <circle cx="1100" cy="40" r="8" />
          <circle cx="1220" cy="160" r="9" />
        </g>

        <text
          x="48"
          y="198"
          fill="#c4a574"
          fontFamily="Fraunces, Georgia, serif"
          fontSize="22"
          letterSpacing="0.08em"
        >
          Nkitahodi
        </text>
        <text
          x="178"
          y="198"
          fill="#8c8980"
          fontFamily="IBM Plex Sans, sans-serif"
          fontSize="11"
        >
          network of collaboration, 2021–2026
        </text>
      </svg>
    </div>
  );
}
