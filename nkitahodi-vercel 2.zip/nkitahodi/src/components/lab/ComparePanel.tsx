import { CiteLink } from "@/components/lab/CiteLink";
import { citedDegree, hopsToKind } from "@/lib/sim/insights";
import { KIND_LABEL, LANGUAGE_LABEL } from "@/lib/sim/types";
import { useLab } from "@/lib/store";

export function ComparePanel() {
  const world = useLab((s) => s.world);
  const selectedId = useLab((s) => s.selectedId);
  const compareId = useLab((s) => s.compareId);
  const select = useLab((s) => s.select);
  const setCompare = useLab((s) => s.setCompare);

  const left = world.agents.find((a) => a.id === selectedId) ?? null;
  const right = world.agents.find((a) => a.id === compareId) ?? null;

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-xs text-muted">
          Organisation A
          <select
            className="mt-1 h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg"
            value={selectedId ?? ""}
            onChange={(e) => select(e.target.value === "" ? null : Number(e.target.value))}
          >
            <option value="">Select</option>
            {world.agents.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-muted">
          Organisation B
          <select
            className="mt-1 h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg"
            value={compareId ?? ""}
            onChange={(e) => setCompare(e.target.value === "" ? null : Number(e.target.value))}
          >
            <option value="">Select</option>
            {world.agents.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Dossier id={left?.id ?? null} />
        <Dossier id={right?.id ?? null} />
      </div>
    </div>
  );
}

function Dossier({ id }: { id: number | null }) {
  const world = useLab((s) => s.world);
  const agent = world.agents.find((a) => a.id === id) ?? null;
  if (!agent) {
    return <p className="text-sm text-muted">Select an organisation to open its dossier.</p>;
  }
  const deg = citedDegree(world, agent.id);
  const toUser = hopsToKind(world, agent.id, "user");
  const toProd = hopsToKind(world, agent.id, "producer");
  const links = world.edges.filter((e) => e.cited && (e.a === agent.id || e.b === agent.id));

  return (
    <article className="rounded-lg border border-border bg-canvas p-4">
      <h3 className="font-display text-lg text-fg">{agent.name}</h3>
      <p className="mt-1 text-xs text-subtle">
        {KIND_LABEL[agent.kind]} · {agent.region} · {agent.sector}
      </p>
      {agent.note && <p className="mt-3 text-sm leading-relaxed text-fg">{agent.note}</p>}
      <dl className="mt-3 space-y-1 text-sm">
        <div className="flex justify-between gap-3">
          <dt className="text-muted">Cited degree</dt>
          <dd className="font-mono tabular-nums">{deg}</dd>
        </div>
        <div className="flex justify-between gap-3">
          <dt className="text-muted">Path to a user</dt>
          <dd className="font-mono tabular-nums">{toUser == null ? "none" : `${toUser} hop${toUser === 1 ? "" : "s"}`}</dd>
        </div>
        <div className="flex justify-between gap-3">
          <dt className="text-muted">Path to a producer</dt>
          <dd className="font-mono tabular-nums">{toProd == null ? "none" : `${toProd} hop${toProd === 1 ? "" : "s"}`}</dd>
        </div>
      </dl>
      <p className="mt-3 text-xs text-subtle">
        Languages: {agent.languages.map((l) => LANGUAGE_LABEL[l]).join(", ") || "none stated"}.
      </p>
      <ul className="mt-3 space-y-2 border-t border-border pt-3">
        {links.map((e) => {
          const other = world.agents.find((x) => x.id === (e.a === agent.id ? e.b : e.a));
          return (
            <li key={`${e.a}-${e.b}`}>
              <p className="text-sm text-fg">
                {other?.name}
                {e.date ? <span className="ml-2 font-mono text-xs text-mark">{e.date}</span> : null}
              </p>
              <CiteLink source={e.source} evidence={e.evidence} href={e.href} />
            </li>
          );
        })}
      </ul>
    </article>
  );
}
