import { LANGUAGE_LABEL, LANGUAGES, type Language } from "@/lib/sim/types";
import { useLab } from "@/lib/store";
import { cn } from "@/lib/utils";

export function LanguageBar() {
  const world = useLab((s) => s.world);
  const focus = useLab((s) => s.focusLang);
  const setFocus = useLab((s) => s.setFocusLang);

  const counts = Object.fromEntries(
    LANGUAGES.map((lang) => [
      lang,
      world.agents.filter((a) => a.languages.includes(lang)).length,
    ]),
  ) as Record<Language, number>;

  return (
    <div className="flex flex-wrap gap-2" role="list" aria-label="Ghanaian languages on this record">
      {LANGUAGES.filter((lang) => counts[lang] > 0).map((lang) => {
        const on = focus === lang;
        return (
          <button
            key={lang}
            type="button"
            onClick={() => setFocus(on ? null : lang)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-sm",
              on
                ? "border-mark bg-mark text-accent-fg"
                : "border-border text-muted hover:text-fg",
            )}
          >
            {LANGUAGE_LABEL[lang]}
            <span className="ml-1.5 font-mono text-xs tabular-nums opacity-80">{counts[lang]}</span>
          </button>
        );
      })}
    </div>
  );
}
