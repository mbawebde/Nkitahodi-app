export function HighlightPanel() {
  return null;
}
