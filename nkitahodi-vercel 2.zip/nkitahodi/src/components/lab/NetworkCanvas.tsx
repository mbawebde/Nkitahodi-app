import { useEffect, useMemo, useRef } from "react";
import { citedDegree } from "@/lib/sim/insights";
import { CLUSTER_CENTRE, CLUSTER_LABEL, clusterOf } from "@/lib/sim/layout";
import { edgeYear, visibleIds } from "@/lib/sim/filters";
import { componentOf, shortestPath } from "@/lib/sim/paths";
import { ROLE_SPEC } from "@/lib/sim/roles";
import { articulationPoints, betweenness } from "@/lib/sim/structure";
import type { Agent, AgentKind } from "@/lib/sim/types";
import { useLab } from "@/lib/store";

function shortName(name: string) {
  const cut = name.replace(" / ", " ").split(" (")[0] ?? name;
  return cut.length > 20 ? `${cut.slice(0, 18)}…` : cut;
}

function drawRole(ctx: CanvasRenderingContext2D, kind: AgentKind, x: number, y: number, r: number) {
  ctx.beginPath();
  if (kind === "producer") ctx.rect(x - r, y - r, r * 2, r * 2);
  else if (kind === "intermediary") {
    ctx.moveTo(x, y - r);
    ctx.lineTo(x + r, y);
    ctx.lineTo(x, y + r);
    ctx.lineTo(x - r, y);
    ctx.closePath();
  } else ctx.arc(x, y, r, 0, Math.PI * 2);
}

const RING_R = 168;

function ringPos(i: number, n: number) {
  const angle = (i / Math.max(1, n)) * Math.PI * 2 - Math.PI / 2;
  return { x: Math.cos(angle) * RING_R, y: Math.sin(angle) * RING_R, angle };
}

function posOf(agent: Agent, agents: Agent[], mode: "ring" | "cluster") {
  if (mode === "cluster") return { x: agent.x, y: agent.y, angle: 0 };
  const i = agents.findIndex((a) => a.id === agent.id);
  return ringPos(i < 0 ? 0 : i, agents.length);
}

function hitTest(agents: Agent[], x: number, y: number, mode: "ring" | "cluster", radius = 36) {
  let bestId: number | null = null;
  let bestD = radius;
  for (const a of agents) {
    const p = posOf(a, agents, mode);
    const d = Math.hypot(p.x - x, p.y - y);
    if (d < bestD) {
      bestD = d;
      bestId = a.id;
    }
    if (mode === "ring") {
      const lx = Math.cos(p.angle) * (RING_R + 36);
      const ly = Math.sin(p.angle) * (RING_R + 36);
      const dl = Math.hypot(lx - x, ly - y);
      if (dl < 32 && dl < bestD) {
        bestD = dl;
        bestId = a.id;
      }
    } else {
      const dl = Math.hypot(p.x - x, p.y + 16 - y);
      if (dl < 28 && dl < bestD) {
        bestD = dl;
        bestId = a.id;
      }
    }
  }
  return bestId;
}

export function NetworkCanvas({ mode }: { mode: "ring" | "cluster" }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const select = useLab((s) => s.select);
  const setHover = useLab((s) => s.setHover);
  const hoverId = useLab((s) => s.hoverId);
  const world = useLab((s) => s.world);
  const hovered = world.agents.find((a) => a.id === hoverId) ?? null;
  const bcHover = useMemo(() => (hovered ? betweenness(world).get(hovered.id) ?? 0 : 0), [hovered, world]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    let dpr = 1;
    let cachedWorld = useLab.getState().world;
    let bc = betweenness(cachedWorld);
    let cuts = new Set(articulationPoints(cachedWorld));
    let maxBc = Math.max(1, ...bc.values());

    const token = (name: string, fallback: string) =>
      getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = wrap.clientWidth;
      h = wrap.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const toWorld = (ev: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
    const scale = Math.min(w, h) / (mode === "ring" ? 640 : 560);
      return {
        x: (ev.clientX - rect.left - w / 2) / scale,
        y: (ev.clientY - rect.top - h / 2) / scale,
      };
    };

    const draw = () => {
      const {
        world,
        selectedId: sid,
        compareId,
        hoverId,
        focusLang,
        showHost,
        isolate,
        roleFilter,
        markCuts,
        showPath,
        filters,
      } = useLab.getState();
      if (world !== cachedWorld) {
        cachedWorld = world;
        bc = betweenness(world);
        cuts = new Set(articulationPoints(world));
        maxBc = Math.max(1, ...bc.values());
      }

      const keep = new Set<number>(world.agents.map((a) => a.id));
      if (sid != null && isolate === "ego") {
        keep.clear();
        keep.add(sid);
        for (const e of world.edges) {
          if (!e.cited) continue;
          if (!showHost && e.tie === "host") continue;
          if (e.a === sid) keep.add(e.b);
          if (e.b === sid) keep.add(e.a);
        }
      } else if (sid != null && isolate === "component") {
        const comp = componentOf(world, sid, showHost);
        keep.clear();
        for (const id of comp) keep.add(id);
      }

      const filtered = visibleIds(world, filters);
      for (const id of [...keep]) {
        if (!filtered.has(id)) keep.delete(id);
      }

      const path =
        showPath && sid != null && compareId != null
          ? shortestPath(world, sid, compareId, showHost)
          : null;
      const onPath = new Set(path ?? []);

      const agents = world.agents;
      const hot = new Set<number>();
      if (sid != null) {
        hot.add(sid);
        for (const e of world.edges) {
          if (!e.cited) continue;
          if (e.a === sid) hot.add(e.b);
          if (e.b === sid) hot.add(e.a);
        }
      }
      if (hoverId != null) hot.add(hoverId);

      const canvasFill = token("--color-canvas", "#ffffff");
      const thread = token("--color-thread", "#8c8980");
      const mark = token("--color-mark", "#c4a574");
      const producer = token("--color-fg", "#16140f");
      const user = token("--color-success", "#3d5a48");

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = canvasFill;
      ctx.fillRect(0, 0, w, h);

      const scale = Math.min(w, h) / (mode === "ring" ? 640 : 560);
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(scale, scale);

      if (mode === "ring") {
        ctx.strokeStyle = thread;
        ctx.globalAlpha = 0.18;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(0, 0, RING_R, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      } else {
        ctx.font = "11px IBM Plex Sans, sans-serif";
        ctx.fillStyle = token("--color-subtle", "#8c8980");
        ctx.textAlign = "center";
        for (const [id, c] of Object.entries(CLUSTER_CENTRE)) {
          if (id === "bridge") continue;
          ctx.fillText(CLUSTER_LABEL[id as keyof typeof CLUSTER_LABEL], c.x, c.y - 78);
        }
      }

      const pos = (id: number) => {
        const a = agents.find((x) => x.id === id);
        if (!a) return { x: 0, y: 0 };
        return posOf(a, agents, mode);
      };

      for (const e of world.edges) {
        if (!e.cited) continue;
        if (!showHost && e.tie === "host") continue;
        if (!keep.has(e.a) || !keep.has(e.b)) continue;
        const y = edgeYear(e.date);
        if (y != null && !filters.years.includes(y)) continue;
        const a = pos(e.a);
        const b = pos(e.b);
        const lit = sid != null && (e.a === sid || e.b === sid);
        const pathEdge = onPath.has(e.a) && onPath.has(e.b);
        const host = e.tie === "host";
        ctx.strokeStyle = pathEdge || lit ? mark : thread;
        ctx.globalAlpha = pathEdge ? 1 : lit ? 0.95 : host ? 0.22 : 0.22;
        ctx.setLineDash(host ? [5, 4] : []);
        ctx.lineWidth = pathEdge ? 2.6 : lit ? 2.1 : host ? 1 : 1.2;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;

      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!reduce) {
        const now = performance.now() / 3200;
        ctx.fillStyle = mark;
        world.edges.forEach((e, i) => {
          if (!e.cited || e.tie === "host") return;
          if (!keep.has(e.a) || !keep.has(e.b)) return;
          const y = edgeYear(e.date);
          if (y != null && !filters.years.includes(y)) return;
          const lit = sid != null && (e.a === sid || e.b === sid);
          if (sid != null && !lit) return;
          const a = pos(e.a);
          const b = pos(e.b);
          const u = (now + i * 0.11) % 1;
          ctx.globalAlpha = lit ? 0.95 : 0.28;
          ctx.beginPath();
          ctx.arc(a.x + (b.x - a.x) * u, a.y + (b.y - a.y) * u, lit ? 2.4 : 1.6, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.globalAlpha = 1;
      }

      ctx.font = "11px IBM Plex Sans, sans-serif";
      const pulse = 1 + 0.12 * Math.sin(performance.now() / 280);
      for (const agent of agents) {
        if (!keep.has(agent.id)) continue;
        if (roleFilter && agent.kind !== roleFilter && agent.id !== sid) continue;
        const p = posOf(agent, agents, mode);
        const deg = citedDegree(world, agent.id);
        const score = (bc.get(agent.id) ?? 0) / maxBc;
        const r =
          mode === "ring"
            ? 7 + Math.min(deg, 8) * 0.7
            : 6 + score * 10 + Math.min(deg, 4) * 0.3;
        const match = !focusLang || agent.languages.includes(focusLang);
        const lit = hot.has(agent.id) || Boolean(focusLang && match);
        const cut = markCuts && mode === "cluster" && cuts.has(agent.id);
        const rad = agent.id === sid ? r * pulse : lit ? r + 1.2 : r;
        ctx.globalAlpha = focusLang && !match ? 0.12 : 1;
        ctx.fillStyle = lit || agent.id === hoverId ? mark : agent.kind === "user" ? user : producer;
        drawRole(ctx, agent.kind, p.x, p.y, rad);
        ctx.fill();
        if (cut) {
          ctx.strokeStyle = mark;
          ctx.lineWidth = 2;
          ctx.stroke();
        } else if (sid === agent.id) {
          ctx.strokeStyle = producer;
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
        ctx.fillStyle = lit && match ? mark : token("--color-muted", "#5c5954");
        ctx.textAlign = "center";
        if (mode === "ring") {
          const lx = Math.cos(p.angle) * (RING_R + 40);
          const ly = Math.sin(p.angle) * (RING_R + 40);
          ctx.save();
          ctx.translate(lx, ly);
          ctx.rotate(p.angle + (Math.cos(p.angle) < 0 ? Math.PI : 0));
          ctx.fillText(shortName(agent.name), 0, 4);
          ctx.restore();
        } else {
          ctx.fillText(shortName(agent.name), p.x, p.y + r + 12);
        }
        ctx.globalAlpha = 1;
      }
      if (mode === "ring" && sid == null) {
        ctx.fillStyle = producer;
        ctx.globalAlpha = 0.4;
        ctx.font = "13px Fraunces, serif";
        ctx.textAlign = "center";
        ctx.fillText("Select an organisation", 0, 4);
        ctx.globalAlpha = 1;
      }
      ctx.restore();
      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);

    const onClick = (ev: MouseEvent) => {
      const pt = toWorld(ev);
      const { world, selectedId } = useLab.getState();
      const id = hitTest(world.agents, pt.x, pt.y, mode);
      select(id != null && id === selectedId ? null : id);
    };
    const onMove = (ev: MouseEvent) => {
      const pt = toWorld(ev);
      const id = hitTest(useLab.getState().world.agents, pt.x, pt.y, mode, 40);
      setHover(id);
      canvas.style.cursor = id != null ? "pointer" : "default";
    };
    const onLeave = () => {
      setHover(null);
      canvas.style.cursor = "default";
    };

    canvas.addEventListener("click", onClick);
    canvas.addEventListener("mousemove", onMove);
    canvas.addEventListener("mouseleave", onLeave);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("click", onClick);
      canvas.removeEventListener("mousemove", onMove);
      canvas.removeEventListener("mouseleave", onLeave);
    };
  }, [select, setHover, mode]);

  return (
    <div ref={wrapRef} className="relative h-full min-h-80 w-full overflow-hidden bg-canvas">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      <div className="pointer-events-none absolute top-3 left-3 max-w-56 space-y-1 text-[10px] uppercase tracking-wide text-muted">
        {mode === "cluster" ? (
          <>
            <p>Size encodes betweenness (Brandes, 2001)</p>
            <p>Dashed line = institutional host tie</p>
          </>
        ) : (
          <>
            <p>Square producer · diamond intermediate · circle user</p>
            <p>Dashed line = institutional host tie</p>
          </>
        )}
      </div>
      {hovered && (
        <p className="pointer-events-none absolute top-3 right-3 max-w-44 text-right text-xs text-fg">
          {hovered.name}
          <span className="mt-0.5 block text-muted">
            {ROLE_SPEC[hovered.kind].title} · {CLUSTER_LABEL[clusterOf(hovered.name)]}
          </span>
          <span className="mt-0.5 block font-mono text-subtle">path score {bcHover.toFixed(1)}</span>
        </p>
      )}
    </div>
  );
}
