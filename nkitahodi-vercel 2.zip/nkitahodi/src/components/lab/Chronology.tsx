import { CiteLink } from "@/components/lab/CiteLink";
import { citedResults } from "@/lib/sim/results";
import { useLab } from "@/lib/store";

export function Chronology() {
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);
  const r = citedResults(world);
  const maxY = Math.max(1, ...r.years.map((y) => y.n));

  const events = [...world.edges]
    .filter((e) => e.cited)
    .map((e) => ({
      e,
      a: world.agents.find((x) => x.id === e.a),
      b: world.agents.find((x) => x.id === e.b),
      key: e.date ?? "undated",
    }))
    .sort((x, y) => x.key.localeCompare(y.key));

  const groups = new Map<string, typeof events>();
  for (const ev of events) {
    const label = ev.e.date ?? "Date not stated in source";
    const list = groups.get(label) ?? [];
    list.push(ev);
    groups.set(label, list);
  }

  return (
    <div className="space-y-8">
      <div>
        <h3 className="font-display text-lg text-fg">Cited edges by year of source</h3>
        <div className="mt-4 flex h-40 items-end gap-3">
          {r.years.map((y) => (
            <div key={y.year} className="flex flex-1 flex-col items-center gap-2">
              <span className="font-mono text-xs text-muted">{y.n}</span>
              <div
                className="w-full max-w-12 rounded-t-sm bg-mark"
                style={{ height: `${Math.max(8, (y.n / maxY) * 112)}px` }}
              />
              <span className="font-mono text-[10px] text-subtle">{y.year}</span>
            </div>
          ))}
        </div>
      </div>
      <ol className="space-y-5">
        {[...groups.entries()].map(([date, list]) => (
          <li key={date}>
            <p className="font-mono text-xs text-mark">{date}</p>
            <ul className="mt-2 space-y-3">
              {list.map((ev) => (
                <li key={`${ev.e.a}-${ev.e.b}`}>
                  <p className="text-sm text-fg">
                    <button type="button" onClick={() => ev.a && select(ev.a.id)} className="hover:text-accent">
                      {ev.a?.name}
                    </button>
                    <span className="text-subtle"> — </span>
                    <button type="button" onClick={() => ev.b && select(ev.b.id)} className="hover:text-accent">
                      {ev.b?.name}
                    </button>
                  </p>
                  <CiteLink source={ev.e.source} evidence={ev.e.evidence} href={ev.e.href} />
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ol>
    </div>
  );
}
