export function ScenarioBar() {
  return null;
}
