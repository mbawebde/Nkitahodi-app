import { LANGUAGE_LABEL, type Language } from "@/lib/sim/types";
import { useLab } from "@/lib/store";
import { formatNum } from "@/lib/utils";

export function Insights() {
  const m = useLab((s) => s.metrics);
  const robustness = useLab((s) => s.robustness);
  const users = useLab((s) => s.world.agents.filter((a) => a.kind === "user").length);
  const inter = useLab((s) => s.world.agents.filter((a) => a.kind === "intermediary").length);
  const agents = useLab((s) => s.world.agents);

  const notes: string[] = [
    "This map is the public record only: papers, grants, and official strategy statements. No invented organisations.",
    `${inter} intermediates and ${users} users have cited language-AI or AI-strategy links. Most Ghanaian SMEs are absent because they are not named in those sources.`,
  ];

  if (m.clustering > 0.2 && m.avgPath < 3.6) {
    notes.push(
      "Clustering and path length look like a small world on these public links.",
    );
  }

  if (robustness > 0.18) {
    notes.push(
      `The busiest organisation accounts for ${formatNum(robustness)} of cited links if removed. That is a graph fact, not a forecast.`,
    );
  }

  const thinnest = (Object.keys(LANGUAGE_LABEL) as Language[])
    .map((lang) => ({ lang, n: agents.filter((a) => a.languages.includes(lang)).length }))
    .sort((a, b) => a.n - b.n)[0];
  if (thinnest) {
    notes.push(
      `${LANGUAGE_LABEL[thinnest.lang]} is named on the fewest listed organisations (${thinnest.n}).`,
    );
  }

  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <h3 className="font-display text-lg text-fg">Insights</h3>
      <p className="mt-1 text-xs text-subtle">Cited structure only. Incomplete by design.</p>
      <ul className="mt-3 space-y-2.5">
        {notes.slice(0, 5).map((n) => (
          <li key={n} className="text-sm leading-relaxed text-fg/90">
            {n}
          </li>
        ))}
      </ul>
    </div>
  );
}
