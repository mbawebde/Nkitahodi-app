import { citeUrl } from "@/lib/sim/citations";

export function CiteLink({
  source,
  evidence,
  href,
}: {
  source?: string;
  evidence?: string;
  href?: string;
}) {
  const url = href ?? citeUrl(source);
  if (!source && !evidence) return null;
  return (
    <p className="mt-0.5 text-xs leading-relaxed text-subtle">
      {evidence ? <span>{evidence} </span> : null}
      {url ? (
        <a
          href={url}
          target="_blank"
          rel="noreferrer"
          className="text-mark underline decoration-mark/40 underline-offset-2 hover:text-fg"
        >
          {source ?? "Open source"}
        </a>
      ) : source ? (
        <span className="font-mono text-muted">{source}</span>
      ) : null}
    </p>
  );
}
