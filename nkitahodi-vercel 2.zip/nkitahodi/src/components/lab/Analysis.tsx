import { useState } from "react";
import { CentralityTable } from "@/components/lab/CentralityTable";
import { Chronology } from "@/components/lab/Chronology";
import { ComparePanel } from "@/components/lab/ComparePanel";
import { RoleFlows } from "@/components/lab/RoleFlows";
import { StructurePanel } from "@/components/lab/StructurePanel";
import { CitedResults } from "@/components/lab/CitedResults";
import { cn } from "@/lib/utils";

const TABS = [
  { id: "stats", label: "At a glance" },
  { id: "centrality", label: "Who sits in the middle" },
  { id: "time", label: "Timeline" },
  { id: "roles", label: "Roles" },
  { id: "structure", label: "Cut points" },
  { id: "compare", label: "Compare two" },
] as const;

export function Analysis() {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("stats");

  return (
    <section id="analysis" className="rounded-xl border border-border bg-surface">
      <div className="border-b border-border px-4 py-3">
        <h2 className="font-display text-lg text-fg">Analysis</h2>
        <p className="mt-1 text-xs text-muted">
          Size, degree, clustering, mean geodesic distance, betweenness, cut vertices, inter-role
          incidence, and the year of each admitting source. None of these quantities estimates
          adoption.
        </p>
      </div>
      <div className="flex flex-wrap gap-1 border-b border-border px-2 py-2">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "rounded-md px-3 py-2 text-sm",
              tab === t.id ? "bg-elevated text-fg" : "text-muted hover:text-fg",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="p-4">
        {tab === "stats" && <CitedResults />}
        {tab === "centrality" && <CentralityTable />}
        {tab === "time" && <Chronology />}
        {tab === "roles" && <RoleFlows />}
        {tab === "structure" && <StructurePanel />}
        {tab === "compare" && <ComparePanel />}
      </div>
    </section>
  );
}
