export function HelpView() {
  return (
    <section id="help" className="mx-auto max-w-3xl space-y-6 rounded-xl border border-border bg-surface px-5 py-8 text-sm leading-relaxed text-muted">
      <div>
        <h2 className="font-display text-2xl text-fg">How to read Nkitahodi</h2>
        <p className="mt-3">
          Nkitahodi is the interactive companion to a documentary network of collaboration among
          Ghanaian language-technology organisations, 2021–2026. Every organisation and every link is
          admitted from a named public source: a peer-reviewed paper or data article, an official
          laboratory or ministry page, a documented grant award, or the National Artificial
          Intelligence Strategy of 24 April 2026. The figure does not simulate adoption, and it
          does not invent organisations that the public record has not yet named.
        </p>
      </div>
      <div>
        <h3 className="font-display text-lg text-fg">Network</h3>
        <p className="mt-2">
          The Explore panel restricts the visible graph by role (producer, intermediate, user),
          component (main group or isolated names), cited degree (number of public partners), year
          of the source, and attested language. Select an organisation from the list or on the
          figure. The Details panel then reports the cited neighbourhood: every organisation named
          with the selection, the clustering coefficient of that neighbourhood, the mean geodesic
          distance among its members, a sketch of those partners, and the admitting source of each
          link.
        </p>
      </div>
      <div>
        <h3 className="font-display text-lg text-fg">Layouts</h3>
        <ul className="mt-2 list-disc space-y-2 pl-5">
          <li>
            <span className="text-fg">Circular.</span> Organisations occupy the ring in documented
            list order. Node size is cited degree — the number of distinct public partners.
          </li>
          <li>
            <span className="text-fg">Clusters.</span> Organisations are grouped by admitting
            programme: WAXAL and tɛkyerɛma pa (speech); GhanaNLP and Khaya (text); RAIL and AI4D
            (responsible and agricultural AI); the National AI Strategy (policy). Node size is
            betweenness: how often the organisation lies on the shortest path between others.
          </li>
          <li>
            <span className="text-fg">Geography.</span> The same links are placed by the region
            named on the source (Greater Accra, Ashanti, Central, or outside Ghana). This is not a
            cartographic map of Ghana.
          </li>
        </ul>
      </div>
      <div>
        <h3 className="font-display text-lg text-fg">Roles</h3>
        <p className="mt-2">
          Classification follows the function named on the admitting source. Producers generate or
          finance language resources and models (universities, laboratories, industry, funders).
          Intermediates deploy those outputs as platforms, challenges, or extension services.
          Users are named communities or offices of intended adoption. The same organisation may
          perform several functions in the field; the graph records the function attested on the
          source.
        </p>
      </div>
      <div>
        <h3 className="font-display text-lg text-fg">Analysis and languages</h3>
        <p className="mt-2">
          Analysis reports size, degree, clustering, mean geodesic distance, betweenness, cut
          vertices, inter-role incidence, and a year table of source dates. Languages are attached
          only when a source names them. UGSpeechData, WAXAL and tɛkyerɛma pa document speech for
          Akan, Ewe, Dagbani, Dagaare and Ikposo. The GhanaNLP parallel corpora document text for
          Twi, Fante, Ewe, Ga and Kusaal. Khaya’s product record names translation and automatic
          speech recognition, including Dagbani and Gurene. Hausa appears on the continental WAXAL
          list and is not treated as a University of Ghana collection. Dangme, Nzema, Gonja and
          Kasem have no language-AI source on this record.
        </p>
      </div>
      <div>
        <h3 className="font-display text-lg text-fg">What is deferred</h3>
        <p className="mt-2">
          A structured organisational survey, after ethics review. An agent-based calibration on
          released UGSpeechData and WAXAL hours. Culturally grounded evaluation criteria for
          ecosystem-level simulation. Policy recommendations derived from such a simulation. Until
          those steps are complete, the public graph is a reproducible lower bound on who is named
          with whom.
        </p>
      </div>
    </section>
  );
}
