import { LanguageMatrix } from "@/components/lab/LanguageMatrix";
import { citedResults } from "@/lib/sim/results";
import { useLab } from "@/lib/store";

export function LanguagesView() {
  const r = citedResults(useLab((s) => s.world));

  return (
    <section id="languages" className="space-y-4">
      <div className="rounded-xl border border-border bg-surface p-5">
        <h2 className="font-display text-lg text-fg">Language coverage</h2>
        <p className="mt-1 text-sm leading-relaxed text-muted">
          A language is attached to an organisation only when an admitting source names that
          language in connection with the organisation. Counts are therefore attestation counts,
          not speaker populations and not hours of recorded speech. UGSpeechData, WAXAL and
          tɛkyerɛma pa document speech. The GhanaNLP parallel corpora document text. Khaya’s
          product record names translation and automatic speech recognition.
        </p>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-subtle">
                <th className="py-2 pr-3">Language</th>
                <th className="py-2 pr-3">Organisations</th>
                <th className="py-2">Source</th>
              </tr>
            </thead>
            <tbody>
              {r.langCounts.map((row) => (
                <tr key={row.lang} className="border-b border-border">
                  <td className="py-2 pr-3">{row.label}</td>
                  <td className="py-2 pr-3 font-mono">{row.n}</td>
                  <td className="py-2 text-xs text-subtle">{row.source || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-xs text-muted">
          Government-sponsored languages without a language-AI citation on this graph: Dangme,
          Nzema, Gonja, Kasem. Hausa appears on the continental WAXAL list and is not treated as
          a University of Ghana collection.
        </p>
      </div>
      <LanguageMatrix />
    </section>
  );
}
