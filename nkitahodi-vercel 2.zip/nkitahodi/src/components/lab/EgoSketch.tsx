import { neighborsOf } from "@/lib/sim/insights";
import type { Agent } from "@/lib/sim/types";
import { useLab } from "@/lib/store";

export function EgoSketch({ agent }: { agent: Agent }) {
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);
  const setHover = useLab((s) => s.setHover);
  const hoverId = useLab((s) => s.hoverId);
  const nbrs = neighborsOf(world, agent.id, true);
  const cx = 140;
  const cy = 78;
  const r = 52;
  const pts = nbrs.map((n, i) => {
    const a = (i / Math.max(1, nbrs.length)) * Math.PI * 2 - Math.PI / 2;
    return { n, x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r };
  });

  return (
    <svg viewBox="0 0 280 160" className="mt-3 h-40 w-full" role="img" aria-label="Partners of the selected organisation">
      {pts.map((p) => (
        <line
          key={p.n.id}
          x1={cx}
          y1={cy}
          x2={p.x}
          y2={p.y}
          stroke="currentColor"
          className={hoverId === p.n.id ? "text-mark" : "text-border"}
          strokeWidth={hoverId === p.n.id ? 2 : 1}
        />
      ))}
      <text x={cx} y={14} textAnchor="middle" className="fill-muted" fontSize="9">
        Cited neighbourhood
      </text>
      <circle cx={cx} cy={cy} r={10} className="fill-mark" />
      <text x={cx} y={cy + 24} textAnchor="middle" className="fill-fg" fontSize="9">
        {agent.name.length > 22 ? `${agent.name.slice(0, 20)}…` : agent.name}
      </text>
      {pts.map((p) => (
        <g
          key={p.n.id}
          className="cursor-pointer"
          onClick={() => select(p.n.id)}
          onMouseEnter={() => setHover(p.n.id)}
          onMouseLeave={() => setHover(null)}
        >
          <circle cx={p.x} cy={p.y} r={hoverId === p.n.id ? 7 : 5} className="fill-fg" />
          <text x={p.x} y={p.y + 14} textAnchor="middle" className="fill-muted" fontSize="8">
            {p.n.name.length > 16 ? `${p.n.name.slice(0, 14)}…` : p.n.name}
          </text>
        </g>
      ))}
    </svg>
  );
}
