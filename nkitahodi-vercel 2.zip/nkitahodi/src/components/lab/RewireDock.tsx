export function RewireDock() {
  return null;
}
