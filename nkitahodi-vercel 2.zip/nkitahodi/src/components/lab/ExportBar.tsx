import { Download } from "lucide-react";
import { downloadText, edgesCsv, methodsNote, nodesCsv } from "@/lib/sim/export";
import { useLab } from "@/lib/store";
import { Button } from "@/components/ui/button";

export function ExportBar() {
  const world = useLab((s) => s.world);

  const run = () => {
    downloadText("nkitahodi-nodes.csv", nodesCsv(world), "text/csv");
    downloadText("nkitahodi-edges.csv", edgesCsv(world), "text/csv");
    downloadText("nkitahodi-methods.txt", methodsNote(world));
  };

  return (
    <Button variant="outline" size="sm" onClick={run}>
      <Download />
      Export data
    </Button>
  );
}
