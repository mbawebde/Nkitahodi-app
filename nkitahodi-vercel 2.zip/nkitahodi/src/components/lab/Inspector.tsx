import { CiteLink } from "@/components/lab/CiteLink";
import { EgoSketch } from "@/components/lab/EgoSketch";
import { collaborationOf } from "@/lib/sim/collaboration";
import { explainCluster, gapLine, neighborsOf } from "@/lib/sim/insights";
import { CLUSTER_LABEL, clusterOf } from "@/lib/sim/layout";
import { ROLE_SPEC } from "@/lib/sim/roles";
import { KIND_LABEL, LANGUAGE_LABEL } from "@/lib/sim/types";
import { useLab } from "@/lib/store";
import { formatNum } from "@/lib/utils";

export function Inspector() {
  const selectedId = useLab((s) => s.selectedId);
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);
  const setHover = useLab((s) => s.setHover);
  const agent = world.agents.find((a) => a.id === selectedId) ?? null;
  const links = world.edges.filter((e) => e.cited && (e.a === selectedId || e.b === selectedId));

  if (!agent) {
    return (
      <div className="rounded-xl border border-border bg-surface p-5 lg:min-h-[520px]">
        <p className="text-[10px] uppercase tracking-wide text-muted">Details</p>
        <h3 className="mt-1 font-display text-2xl text-fg">Pick an organisation</h3>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Select an organisation from the list or on the figure. This panel then reports the
          cited neighbourhood — every organisation named with the selection — together with the
          clustering coefficient, the mean geodesic distance among those neighbours, a sketch of
          the neighbourhood, and the admitting source of each public link.
        </p>
      </div>
    );
  }

  const spec = ROLE_SPEC[agent.kind];
  const col = collaborationOf(world, agent.id);
  const nbrs = neighborsOf(world, agent.id, true);
  const gap = gapLine(agent, nbrs);
  const structure = explainCluster(col.clustering, col.avgPath, col.size, col.cited);
  const cluster = clusterOf(agent.name);

  return (
    <div className="rounded-xl border border-border bg-surface p-5 lg:min-h-[520px]">
      <p className="text-[10px] uppercase tracking-wide text-muted">
        {KIND_LABEL[agent.kind]} · {spec.who}
      </p>
      <h3 className="mt-1 font-display text-lg text-fg">{agent.name}</h3>
      <p className="mt-1 text-xs text-subtle">
        {agent.region} · {agent.sector} · {CLUSTER_LABEL[cluster]}
      </p>
      {agent.note && <p className="mt-3 text-sm leading-relaxed text-fg">{agent.note}</p>}
      <p className="mt-3 text-sm leading-relaxed text-muted">{spec.does}</p>

      {agent.languages.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {agent.languages.map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => useLab.getState().setFocusLang(l)}
              className="rounded-full border border-mark/50 bg-elevated px-3 py-1 text-sm text-fg"
            >
              {LANGUAGE_LABEL[l]}
            </button>
          ))}
        </div>
      )}

      <div className="mt-4 border-t border-border pt-3">
        <p className="text-[10px] uppercase tracking-wide text-muted">Cited neighbourhood</p>
        <div className="mt-2 grid grid-cols-2 gap-3">
          <div>
            <p className="text-xs text-muted">Clustering coefficient</p>
            <p className="font-display text-2xl tabular-nums text-fg">
              {col.clustering == null ? "n/a" : formatNum(col.clustering, 3)}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted">Mean geodesic distance</p>
            <p className="font-display text-2xl tabular-nums text-fg">
              {col.avgPath == null ? "n/a" : formatNum(col.avgPath, 3)}
            </p>
          </div>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted">{structure}</p>
        {gap && <p className="mt-2 text-sm leading-relaxed text-fg">{gap}</p>}
        <EgoSketch agent={agent} />
      </div>

      {links.length > 0 && (
        <div className="mt-4 border-t border-border pt-3">
          <p className="text-[10px] uppercase tracking-wide text-muted">
            Partners ({links.length})
          </p>
          <ul className="mt-2 max-h-64 space-y-3 overflow-y-auto">
            {links.map((e) => {
              const otherId = e.a === agent.id ? e.b : e.a;
              const other = world.agents.find((a) => a.id === otherId);
              return (
                <li
                  key={`${e.a}-${e.b}`}
                  onMouseEnter={() => setHover(otherId)}
                  onMouseLeave={() => setHover(null)}
                >
                  <button
                    type="button"
                    onClick={() => select(otherId)}
                    className="text-left text-sm text-fg hover:text-accent"
                  >
                    {other?.name ?? "Unknown"}
                    <span className="ml-1 text-xs text-subtle">
                      · {other ? KIND_LABEL[other.kind] : ""}
                      {e.tie === "host" ? " · host" : ""}
                    </span>
                  </button>
                  <CiteLink source={e.source} evidence={e.evidence} href={e.href} />
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
