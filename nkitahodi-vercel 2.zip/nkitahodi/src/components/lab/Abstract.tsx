import { citedResults } from "@/lib/sim/results";
import { formatNum } from "@/lib/utils";
import { useLab } from "@/lib/store";

export function Abstract() {
  const r = citedResults(useLab((s) => s.world));

  return (
    <section id="intro" className="mx-auto max-w-3xl">
      <h2 className="font-display text-lg text-fg">Scope of the record</h2>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        Nkitahodi (Akan: connection) presents a documentary network of collaboration among
        Ghanaian language-technology organisations for the period 2021–2026. An undirected link is included
        only when both organisations are named in a peer-reviewed paper, an official laboratory or
        ministry publication, a documented grant award, or the National Artificial Intelligence
        Strategy of the Republic of Ghana, launched on 24 April 2026. The working graph comprises{" "}
        {r.n} organisations and {r.m} public links in {r.components} connected components. The
        clustering coefficient is {formatNum(r.globalC, 3)}; the mean geodesic distance (average
        shortest-path length among reachable pairs) is {formatNum(r.globalL, 3)}. These quantities
        describe the public record. They do not estimate classroom, farm, or market adoption. The
        study codes documents that announce speech and text resources; it does not ingest audio or
        parallel corpora.
      </p>
    </section>
  );
}
