import { useEffect, useRef } from "react";
import { ROLE_SPEC } from "@/lib/sim/roles";
import type { AgentKind } from "@/lib/sim/types";
import { useLab } from "@/lib/store";

const POS: Record<AgentKind, { x: number; y: number }> = {
  producer: { x: 160, y: 36 },
  intermediary: { x: 48, y: 148 },
  user: { x: 272, y: 148 },
};

const PAIRS: [AgentKind, AgentKind][] = [
  ["producer", "intermediary"],
  ["producer", "user"],
  ["intermediary", "user"],
];

export function RoleFlows() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);

  const counts = {
    producer: world.agents.filter((a) => a.kind === "producer").length,
    intermediary: world.agents.filter((a) => a.kind === "intermediary").length,
    user: world.agents.filter((a) => a.kind === "user").length,
  };

  const flows = PAIRS.map(([a, b]) => ({
    a,
    b,
    n: world.edges.filter((e) => {
      const ka = world.agents.find((x) => x.id === e.a)?.kind;
      const kb = world.agents.find((x) => x.id === e.b)?.kind;
      return e.cited && ((ka === a && kb === b) || (ka === b && kb === a));
    }).length,
  }));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    const w = 320;
    const h = 188;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;

    const cited = world.edges;
    const agents = world.agents;
    const flowNow = PAIRS.map(([a, b]) => ({
      a,
      b,
      n: cited.filter((e) => {
        const ka = agents.find((x) => x.id === e.a)?.kind;
        const kb = agents.find((x) => x.id === e.b)?.kind;
        return e.cited && ((ka === a && kb === b) || (ka === b && kb === a));
      }).length,
    }));

    const draw = (t: number) => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      for (const f of flowNow) {
        const p = POS[f.a];
        const q = POS[f.b];
        if (!f.n) {
          ctx.strokeStyle = "rgba(236,234,228,0.08)";
          ctx.setLineDash([4, 4]);
        } else {
          ctx.strokeStyle = "rgba(196,165,116,0.55)";
          ctx.setLineDash([]);
        }
        ctx.lineWidth = f.n ? Math.min(5, 1 + f.n * 0.18) : 1;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(q.x, q.y);
        ctx.stroke();
        if (f.n && !reduce) {
          const u = (t / 2800 + f.n * 0.07) % 1;
          const x = p.x + (q.x - p.x) * u;
          const y = p.y + (q.y - p.y) * u;
          ctx.fillStyle = "#c4a574";
          ctx.beginPath();
          ctx.arc(x, y, 2.4, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [world]);

  const pickKind = (kind: AgentKind) => {
    const members = world.agents
      .filter((a) => a.kind === kind)
      .map((a) => ({
        a,
        d: world.edges.filter((e) => e.a === a.id || e.b === a.id).length,
      }))
      .sort((x, y) => y.d - x.d);
    if (members[0]) select(members[0].a.id);
  };

  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <h2 className="font-display text-lg text-fg">Incidence among roles</h2>
      <p className="mt-1 text-xs text-muted">
        Line width is proportional to the number of cited links between classes. Absence of a
        line means no public source names both classes together.
      </p>
      <div className="relative mx-auto mt-2 w-[320px] max-w-full">
        <canvas ref={canvasRef} className="block" />
        <button
          type="button"
          onClick={() => pickKind("producer")}
          className="absolute top-1 left-1/2 w-28 -translate-x-1/2 rounded-md border border-border bg-elevated px-2 py-1.5 text-center text-[11px] text-fg"
        >
          Producers
          <span className="block font-mono text-muted">{counts.producer}</span>
        </button>
        <button
          type="button"
          onClick={() => pickKind("intermediary")}
          className="absolute bottom-1 left-2 w-28 rounded-md border border-border bg-elevated px-2 py-1.5 text-center text-[11px] text-fg"
        >
          Intermediates
          <span className="block font-mono text-muted">{counts.intermediary}</span>
        </button>
        <button
          type="button"
          onClick={() => pickKind("user")}
          className="absolute right-2 bottom-1 w-28 rounded-md border border-border bg-elevated px-2 py-1.5 text-center text-[11px] text-fg"
        >
          Users
          <span className="block font-mono text-muted">{counts.user}</span>
        </button>
      </div>
      <ul className="mt-2 space-y-1 text-xs text-subtle">
        {flows.map((f) => (
          <li key={`${f.a}-${f.b}`}>
            {ROLE_SPEC[f.a].title} — {ROLE_SPEC[f.b].title}: {f.n} cited edge{f.n === 1 ? "" : "s"}
            {f.n === 0 ? " — absent from the public record" : ""}
          </li>
        ))}
      </ul>
    </div>
  );
}
