import { Sheet } from "@/components/ui/sheet";

export function AboutModel({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="Construction of the record">
      <div className="space-y-5 text-sm leading-relaxed text-muted">
        <section>
          <h3 className="mb-1 font-display text-base text-fg">Name</h3>
          <p>
            Nkitahodi is Akan for connection, contact, the ties among people and organisations.
            That is the object of study: cited partnerships around Ghanaian languages. The name is
            not an existing commercial title.
          </p>
        </section>
        <section>
          <h3 className="mb-1 font-display text-base text-fg">Admission rule</h3>
          <p>
            An organisation or link is included only when both endpoints are named in a
            peer-reviewed paper, an official laboratory or ministry publication, a documented grant
            award, or the National Artificial Intelligence Strategy of 24 April 2026. Survey
            responses, social-media comments, accreditation relationships without a language-AI
            project, and inferred partnerships are excluded.
          </p>
        </section>
        <section>
          <h3 className="mb-1 font-display text-base text-fg">Roles</h3>
          <p>
            Producers generate or finance models and corpora. Intermediates deploy those outputs.
            Users are named communities or offices of intended adoption. Classification follows the
            organisation’s function on the admitting source, not a survey of self-identification.
          </p>
        </section>
        <section>
          <h3 className="mb-1 font-display text-base text-fg">Languages</h3>
          <p>
            A language is attached to an organisation only when that source names it. UGSpeechData
            and tɛkyerɛma pa name Akan, Ewe, Dagbani, Dagaare and Ikposo. The GhanaNLP corpora name
            Twi, Fante, Ewe, Ga and Kusaal. Khaya’s product documentation names Dagbani and Gurene.
            Hausa appears on the continental WAXAL list and is not attributed to the University of
            Ghana as a collection mark.
          </p>
        </section>
        <section>
          <h3 className="mb-1 font-display text-base text-fg">Graph and layout</h3>
          <p>
            Three drawings show the same cited links. Circular: position is list order; size is
            cited degree. Clusters: groups follow the admitting programme; size is betweenness
            (Brandes, 2001), not the clustering coefficient. Geography: position is the location
            named on that source. Host ties (University of Ghana–HCI Laboratory; KNUST–RAIL) are
            institutional containment. Clustering coefficient and mean geodesic distance in Details
            describe the selected neighbourhood only.
          </p>
        </section>
        <section>
          <h3 className="mb-1 font-display text-base text-fg">What is excluded</h3>
          <p>
            Simulated adoption, rewired links, and organisations without a language-AI citation —
            including government-sponsored languages with no corpus on this record — are omitted.
          </p>
        </section>
      </div>
    </Sheet>
  );
}
