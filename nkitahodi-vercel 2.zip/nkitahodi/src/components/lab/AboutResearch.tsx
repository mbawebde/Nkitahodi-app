export function AboutResearch() {
  return (
    <section id="about" className="rounded-xl border border-border bg-surface px-5 py-6 md:px-8 md:py-8">
      <p className="text-[10px] uppercase tracking-wide text-muted">Construction of the record</p>
      <h2 className="mt-1 font-display text-2xl text-fg">How the network is constructed</h2>
      <div className="mt-4 max-w-3xl space-y-4 text-sm leading-relaxed text-muted">
        <p>
          The unit of analysis is the public tie. Both endpoints must be named in one admitting
          source. Dates are the publication or announcement dates of those sources, not inferred
          onsets of collaboration. Where a source states only a year, that year is retained.
          Host links record institutional containment (University of Ghana–HCI Laboratory;
          KNUST–RAIL). Project links record grants, consortia, and jointly named programmes.
        </p>
        <p>
          Organisations are classified by function on the admitting source. Producers generate or
          finance resources and models. Intermediates deploy those outputs. Users are named
          communities or offices of intended use. A language is attached only when the source
          names it. UGSpeechData, WAXAL and tɛkyerɛma pa document speech. The GhanaNLP parallel
          corpora document text. Khaya’s product record names both translation and automatic
          speech recognition. RAIL’s public record is agricultural, not linguistic; it is retained
          because the National AI Strategy frames language technology within a broader national
          ecosystem, not because RAIL produces a Ghanaian-language corpus.
        </p>
        <p>
          The clustering coefficient is the mean local transitivity of the undirected public graph
          (Watts and Strogatz, 1998): for each organisation with at least two partners, the
          proportion of those partners that are themselves linked, then averaged. Mean geodesic
          distance is the average shortest-path length over reachable pairs. Betweenness follows
          Brandes (2001) and identifies organisations that lie on many shortest paths.
          Articulation points are organisations whose removal would increase the number of
          disconnected groups. All four quantities describe the public record. None is an estimate
          of knowledge transfer or of tool uptake.
        </p>
        <p>
          Survey responses, informal social-media commentary, accreditation relationships without
          a language-AI project, and simulated uptake are excluded. Subsequent work may add an
          organisational survey, after ethics review, and an agent-based calibration on released
          UGSpeechData and WAXAL hours. Those steps are not required to read the present graph.
        </p>
      </div>
    </section>
  );
}
