import { useState } from "react";
import { CiteLink } from "@/components/lab/CiteLink";
import { marksFor } from "@/lib/sim/languageCoverage";
import { KIND_LABEL, LANGUAGE_LABEL, LANGUAGES, type Language } from "@/lib/sim/types";
import { useLab } from "@/lib/store";
import { cn } from "@/lib/utils";

export function LanguageMatrix() {
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);
  const setFocus = useLab((s) => s.setFocusLang);
  const focus = useLab((s) => s.focusLang);
  const langs = LANGUAGES.filter((l) => world.agents.some((a) => a.languages.includes(l)));
  const rows = [...world.agents].sort((a, b) => {
    const da = a.languages.length ? 0 : 1;
    const db = b.languages.length ? 0 : 1;
    return da - db || a.name.localeCompare(b.name);
  });

  const [cell, setCell] = useState<{ org: string; lang: Language } | null>(null);
  const detail = cell ? marksFor(cell.org, cell.lang) : [];

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] border-collapse text-left text-sm">
          <caption className="mb-3 text-left text-xs text-muted">
            A filled cell is attested in a named source. Hausa appears on the continental WAXAL
            list published by Google Research Africa and is not a University of Ghana collection
            mark. Dangme, Nzema, Gonja and Kasem have no language-AI source on this graph.
          </caption>
          <thead>
            <tr className="border-b border-border">
              <th className="py-2 pr-3 font-normal text-muted">Organisation</th>
              <th className="py-2 pr-3 font-normal text-muted">Role</th>
              {langs.map((l) => (
                <th key={l} className="px-1 py-2 text-center font-normal">
                  <button
                    type="button"
                    onClick={() => setFocus(focus === l ? null : l)}
                    className={focus === l ? "text-mark" : "text-muted"}
                  >
                    {LANGUAGE_LABEL[l]}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((a) => (
              <tr key={a.id} className="border-b border-border/70">
                <td className="py-1.5 pr-3">
                  <button type="button" onClick={() => select(a.id)} className="text-fg hover:text-accent">
                    {a.name}
                  </button>
                </td>
                <td className="py-1.5 pr-3 text-subtle">{KIND_LABEL[a.kind]}</td>
                {langs.map((l) => {
                  const hits = marksFor(a.name, l);
                  const on = cell?.org === a.name && cell.lang === l;
                  return (
                    <td key={l} className="px-1 py-1 text-center">
                      {hits.length > 0 ? (
                        <button
                          type="button"
                          aria-label={`${a.name}, ${LANGUAGE_LABEL[l]}, ${hits.length} source${hits.length === 1 ? "" : "s"}`}
                          onClick={() => {
                            setCell(on ? null : { org: a.name, lang: l });
                            select(a.id);
                            setFocus(l);
                          }}
                          className={cn(
                            "inline-flex min-h-8 min-w-8 items-center justify-center rounded-sm text-xs",
                            on ? "bg-mark text-accent-fg" : "text-mark hover:bg-elevated",
                          )}
                        >
                          {hits.length}
                        </button>
                      ) : null}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {cell && (
        <aside className="mt-4 rounded-lg border border-border bg-canvas p-4">
          <p className="text-[10px] uppercase tracking-wide text-muted">Admitting sources</p>
          <h3 className="mt-1 font-display text-lg text-fg">
            {cell.org} · {LANGUAGE_LABEL[cell.lang]}
          </h3>
          {detail.length === 0 ? (
            <p className="mt-2 text-sm text-muted">No language-specific citation.</p>
          ) : (
            <ol className="mt-3 list-decimal space-y-3 pl-4">
              {detail.map((m) => (
                <li key={`${m.source}-${m.evidence.slice(0, 24)}`} className="text-sm text-fg">
                  <CiteLink source={m.source} evidence={m.evidence} />
                </li>
              ))}
            </ol>
          )}
        </aside>
      )}
    </div>
  );
}
