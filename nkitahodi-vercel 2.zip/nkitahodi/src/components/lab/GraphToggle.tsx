import { useLab } from "@/lib/store";

export function GraphToggle() {
  const n = useLab((s) => s.world.agents.length);
  const e = useLab((s) => s.world.edges.length);

  return (
    <p className="text-[11px] text-subtle">
      {n} organisations · {e} cited edges · public record only
    </p>
  );
}
