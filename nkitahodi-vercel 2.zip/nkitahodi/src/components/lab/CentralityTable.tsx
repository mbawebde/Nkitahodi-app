import { useState } from "react";
import { citedDegree } from "@/lib/sim/insights";
import { collaborationOf } from "@/lib/sim/collaboration";
import { betweenness } from "@/lib/sim/structure";
import { KIND_LABEL } from "@/lib/sim/types";
import { useLab } from "@/lib/store";
import { formatNum } from "@/lib/utils";

type SortKey = "degree" | "betweenness" | "clustering";

export function CentralityTable() {
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);
  const setView = useLab((s) => s.setView);
  const [sortBy, setSortBy] = useState<SortKey>("degree");
  const [limit, setLimit] = useState(10);
  const bc = betweenness(world);

  const rows = world.agents
    .map((a) => ({
      a,
      degree: citedDegree(world, a.id),
      betweenness: bc.get(a.id) ?? 0,
      clustering: collaborationOf(world, a.id).clustering ?? 0,
    }))
    .sort((x, y) => y[sortBy] - x[sortBy]);
  const shown = limit === 0 ? rows : rows.slice(0, limit);

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
        <h3 className="font-display text-lg text-fg">Centrality</h3>
        <div className="flex flex-wrap gap-2 text-xs">
          <label className="text-muted">
            Sort
            <select
              className="ml-2 h-9 rounded-md border border-border bg-elevated px-2 text-fg"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortKey)}
            >
              <option value="degree">Partners</option>
              <option value="betweenness">Path score</option>
              <option value="clustering">Clustering</option>
            </select>
          </label>
          <label className="text-muted">
            Show
            <select
              className="ml-2 h-9 rounded-md border border-border bg-elevated px-2 text-fg"
              value={limit}
              onChange={(e) => setLimit(Number(e.target.value))}
            >
              <option value={5}>Top 5</option>
              <option value={10}>Top 10</option>
              <option value={20}>Top 20</option>
              <option value={0}>All</option>
            </select>
          </label>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-xs text-subtle">
              <th className="py-2 pr-2">#</th>
              <th className="py-2 pr-2">Organisation</th>
              <th className="py-2 pr-2">Role</th>
              <th className="py-2 pr-2">Partners</th>
              <th className="py-2 pr-2">Path score</th>
              <th className="py-2">Clustering</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((row, i) => (
              <tr key={row.a.id} className="border-b border-border">
                <td className="py-2 pr-2 font-mono text-subtle">{i + 1}</td>
                <td className="py-2 pr-2">
                  <button
                    type="button"
                    className="text-left text-fg hover:text-accent"
                    onClick={() => {
                      select(row.a.id);
                      setView("network");
                    }}
                  >
                    {row.a.name}
                  </button>
                </td>
                <td className="py-2 pr-2 text-muted">{KIND_LABEL[row.a.kind]}</td>
                <td className="py-2 pr-2 font-mono">{row.degree}</td>
                <td className="py-2 pr-2 font-mono">{formatNum(row.betweenness, 2)}</td>
                <td className="py-2 font-mono">{formatNum(row.clustering, 3)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
