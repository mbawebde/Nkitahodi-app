import { useLab } from "@/lib/store";

export function EventLog() {
  const events = useLab((s) => s.world.events);

  return (
    <div className="flex h-full min-h-[180px] flex-col rounded-xl border border-border bg-surface p-4">
      <h3 className="mb-3 font-display text-lg text-fg">What just moved</h3>
      <ol className="min-h-0 flex-1 space-y-2 overflow-y-auto pr-1">
        {events.length === 0 && <li className="text-sm text-subtle">No events yet.</li>}
        {events.map((e, i) => (
          <li key={`${e.tick}-${i}`} className="border-l border-border pl-3 text-xs leading-relaxed">
            <span className="font-mono tabular-nums text-subtle">t{e.tick}</span>
            <span className="ml-2 text-fg/90">{e.text}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}
