export function RewirePlots() {
  return null;
}
