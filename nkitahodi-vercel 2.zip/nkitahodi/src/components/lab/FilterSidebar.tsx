import { ROLE_SPEC } from "@/lib/sim/roles";
import { ALL_YEARS, mainComponentIds, visibleIds } from "@/lib/sim/filters";
import { citedResults } from "@/lib/sim/results";
import type { AgentKind, Language } from "@/lib/sim/types";
import { KIND_LABEL, LANGUAGE_LABEL, LANGUAGES } from "@/lib/sim/types";
import { useLab } from "@/lib/store";
import { formatNum } from "@/lib/utils";
import { cn } from "@/lib/utils";

const ROLES: AgentKind[] = ["producer", "intermediary", "user"];

export function FilterSidebar() {
  const world = useLab((s) => s.world);
  const filters = useLab((s) => s.filters);
  const patch = useLab((s) => s.patchFilters);
  const reset = useLab((s) => s.resetFilters);
  const selectedId = useLab((s) => s.selectedId);
  const select = useLab((s) => s.select);
  const r = citedResults(world);
  const main = mainComponentIds(world);
  const visible = visibleIds(world, filters);

  const roleCounts = {
    producer: world.agents.filter((a) => a.kind === "producer" && visible.has(a.id)).length,
    intermediary: world.agents.filter((a) => a.kind === "intermediary" && visible.has(a.id)).length,
    user: world.agents.filter((a) => a.kind === "user" && visible.has(a.id)).length,
  };
  const mainN = world.agents.filter((a) => main.has(a.id) && visible.has(a.id)).length;
  const isoN = world.agents.filter((a) => !main.has(a.id) && visible.has(a.id)).length;
  const edgeN = world.edges.filter(
    (e) => e.cited && visible.has(e.a) && visible.has(e.b),
  ).length;

  const toggleRole = (role: AgentKind) => {
    const next = filters.roles.includes(role)
      ? filters.roles.filter((x) => x !== role)
      : [...filters.roles, role];
    patch({ roles: next.length ? next : [role] });
  };

  const toggleYear = (y: number) => {
    const next = filters.years.includes(y)
      ? filters.years.filter((x) => x !== y)
      : [...filters.years, y].sort();
    patch({ years: next.length ? next : [y] });
  };

  return (
    <aside className="rounded-xl border border-border bg-surface" aria-label="Controls">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h2 className="font-display text-lg text-fg">Explore</h2>
        <span className="font-mono text-xs text-subtle">{visible.size} visible</span>
      </div>
      <div className="max-h-[calc(100dvh-220px)] space-y-6 overflow-y-auto px-4 py-4 lg:max-h-[720px]">
        <div>
          <label className="text-[10px] font-medium uppercase tracking-wide text-subtle">Search</label>
          <input
            type="search"
            value={filters.searchTerm}
            onChange={(e) => patch({ searchTerm: e.target.value })}
            placeholder="Search organisations…"
            className="mt-2 h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg"
          />
        </div>

        <div>
          <label className="text-[10px] font-medium uppercase tracking-wide text-subtle">Organisation</label>
          <select
            className="mt-2 h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg"
            value={selectedId ?? ""}
            onChange={(e) => select(e.target.value === "" ? null : Number(e.target.value))}
          >
            <option value="">Select…</option>
            {world.agents
              .filter((a) => visible.has(a.id))
              .slice()
              .sort((a, b) => a.name.localeCompare(b.name))
              .map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
          </select>
        </div>

        <div>
          <p className="text-[10px] font-medium uppercase tracking-wide text-subtle">Role</p>
          <div className="mt-2 space-y-1">
            {ROLES.map((role) => (
              <label key={role} className="flex h-10 cursor-pointer items-center gap-2 rounded-md px-2 text-sm hover:bg-elevated">
                <input
                  type="checkbox"
                  checked={filters.roles.includes(role)}
                  onChange={() => toggleRole(role)}
                  className="accent-fg"
                />
                <span
                  className={cn(
                    "inline-block size-2.5 shrink-0",
                    role === "producer" && "bg-fg",
                    role === "intermediary" && "rotate-45 bg-mark",
                    role === "user" && "rounded-full bg-success",
                  )}
                />
                {KIND_LABEL[role]}
                <span className="ml-auto font-mono text-xs text-subtle">{roleCounts[role]}</span>
              </label>
            ))}
          </div>
          <p className="mt-1 text-xs text-subtle">{ROLE_SPEC.producer.who}</p>
        </div>

        <div>
          <p className="text-[10px] font-medium uppercase tracking-wide text-subtle">Component</p>
          <label className="mt-2 flex h-10 cursor-pointer items-center gap-2 rounded-md px-2 text-sm hover:bg-elevated">
            <input
              type="checkbox"
              checked={filters.showMain}
              onChange={() => patch({ showMain: !filters.showMain })}
              className="accent-fg"
            />
            Main
            <span className="ml-auto font-mono text-xs text-subtle">{mainN}</span>
          </label>
          <label className="flex h-10 cursor-pointer items-center gap-2 rounded-md px-2 text-sm hover:bg-elevated">
            <input
              type="checkbox"
              checked={filters.showIsolated}
              onChange={() => patch({ showIsolated: !filters.showIsolated })}
              className="accent-fg"
            />
            Isolated
            <span className="ml-auto font-mono text-xs text-subtle">{isoN}</span>
          </label>
        </div>

        <div>
          <p className="text-[10px] font-medium uppercase tracking-wide text-subtle">
            Partners · {filters.minDegree}–{filters.maxDegree}
          </p>
          <input
            type="range"
            min={0}
            max={12}
            value={filters.minDegree}
            onChange={(e) =>
              patch({ minDegree: Math.min(Number(e.target.value), filters.maxDegree) })
            }
            className="mt-2 w-full accent-fg"
          />
          <input
            type="range"
            min={0}
            max={12}
            value={filters.maxDegree}
            onChange={(e) =>
              patch({ maxDegree: Math.max(Number(e.target.value), filters.minDegree) })
            }
            className="w-full accent-fg"
          />
        </div>

        <div>
          <p className="text-[10px] font-medium uppercase tracking-wide text-subtle">Year</p>
          <div className="mt-2 flex flex-wrap gap-1">
            {ALL_YEARS.map((y) => (
              <button
                key={y}
                type="button"
                onClick={() => toggleYear(y)}
                className={cn(
                  "h-9 rounded-md px-2.5 text-xs",
                  filters.years.includes(y) ? "bg-fg text-accent-fg" : "border border-border text-muted",
                )}
              >
                {y}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-[10px] font-medium uppercase tracking-wide text-subtle">Language</label>
          <select
            className="mt-2 h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg"
            value={filters.language ?? ""}
            onChange={(e) =>
              patch({ language: e.target.value === "" ? null : (e.target.value as Language) })
            }
          >
            <option value="">All languages</option>
            {LANGUAGES.map((l) => (
              <option key={l} value={l}>
                {LANGUAGE_LABEL[l]}
              </option>
            ))}
          </select>
        </div>

        <div>
          <p className="text-[10px] font-medium uppercase tracking-wide text-subtle">Legend</p>
          <ul className="mt-2 space-y-1.5 text-sm text-muted">
            <li className="flex items-center gap-2">
              <span className="inline-block size-3 bg-fg" /> Producer
            </li>
            <li className="flex items-center gap-2">
              <span className="inline-block size-2.5 rotate-45 bg-mark" /> Intermediate
            </li>
            <li className="flex items-center gap-2">
              <span className="inline-block size-3 rounded-full bg-success" /> User
            </li>
            <li className="flex items-center gap-2">
              <span className="inline-block h-px w-5 bg-fg" /> Project edge
            </li>
            <li className="flex items-center gap-2">
              <span className="inline-block h-px w-5 border-t border-dashed border-subtle" /> Host edge
            </li>
          </ul>
        </div>

        <div className="grid grid-cols-2 gap-2 rounded-md bg-elevated p-3">
          <Stat k="Orgs" v={String(visible.size)} />
          <Stat k="Links" v={String(edgeN)} />
          <Stat k="Groups" v={String(r.components)} />
          <Stat k="Clustering" v={formatNum(r.globalC, 3)} />
        </div>

        <p className="font-mono text-[11px] text-subtle">
          Full record: {world.agents.length} organisations · {world.edges.filter((e) => e.cited).length}{" "}
          links · {formatNum(r.degree.mean, 2)} partners on average.
        </p>

        <button
          type="button"
          onClick={reset}
          className="h-11 w-full rounded-md border border-border-strong text-sm text-fg hover:bg-elevated"
        >
          Reset filters
        </button>
      </div>
    </aside>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="text-center">
      <span className="block text-[10px] uppercase tracking-wide text-subtle">{k}</span>
      <span className="font-display text-xl text-fg">{v}</span>
    </div>
  );
}
