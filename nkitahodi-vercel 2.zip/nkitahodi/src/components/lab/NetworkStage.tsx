import { useState } from "react";
import { GeoNetwork } from "@/components/lab/GeoNetwork";
import { LanguageBar } from "@/components/lab/LanguageBar";
import { NetworkCanvas } from "@/components/lab/NetworkCanvas";
import { useLab } from "@/lib/store";
import { cn } from "@/lib/utils";

const VIEWS = [
  {
    id: "ring",
    label: "Circular",
    blurb:
      "Circular embedding of the public graph. Angular order is the documented list. Node size is cited degree — the number of distinct public partners.",
  },
  {
    id: "cluster",
    label: "Clusters",
    blurb:
      "Organisations grouped by admitting programme (WAXAL / tɛkyerɛma pa; GhanaNLP; RAIL / AI4D; National AI Strategy). Node size is betweenness (Brandes, 2001): how often the organisation lies on the shortest path between others.",
  },
  {
    id: "geo",
    label: "Geography",
    blurb:
      "The same public links, placed by the region named on the source (Greater Accra, Ashanti, Central, or outside Ghana). This is not a cartographic map of Ghana.",
  },
] as const;

export function NetworkStage() {
  const [view, setView] = useState<(typeof VIEWS)[number]["id"]>("ring");
  const n = useLab((s) => s.world.agents.length);
  const e = useLab((s) => s.world.edges.length);
  const current = VIEWS.find((v) => v.id === view)!;

  return (
    <section id="map" className="min-w-0 overflow-hidden rounded-xl border border-border bg-elevated">
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border px-4 py-3">
        <div className="min-w-0">
          <h2 className="font-display text-lg text-fg">Network</h2>
          <p className="text-xs text-subtle">{current.blurb}</p>
        </div>
        <p className="font-mono text-xs tabular-nums text-muted">
          {n} organisations · {e} links
        </p>
      </div>
      <div className="flex flex-wrap gap-1 border-b border-border px-2 py-2">
        {VIEWS.map((v) => (
          <button
            key={v.id}
            type="button"
            onClick={() => setView(v.id)}
            className={cn(
              "rounded-md px-3 py-2 text-sm",
              view === v.id ? "bg-canvas text-fg" : "text-muted hover:text-fg",
            )}
          >
            {v.label}
          </button>
        ))}
      </div>
      {view !== "geo" && (
        <div className="border-b border-border px-4 py-3">
          <LanguageBar />
        </div>
      )}
      {view === "ring" && (
        <div className="h-[420px] md:h-[520px]">
          <NetworkCanvas mode="ring" />
        </div>
      )}
      {view === "cluster" && (
        <div className="h-[420px] md:h-[520px]">
          <NetworkCanvas mode="cluster" />
        </div>
      )}
      {view === "geo" && <GeoNetwork embedded />}
    </section>
  );
}
