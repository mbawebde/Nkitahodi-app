import { ROLE_SPEC } from "@/lib/sim/roles";
import type { AgentKind } from "@/lib/sim/types";
import { useLab } from "@/lib/store";

const ROLES: AgentKind[] = ["producer", "intermediary", "user"];

export function OrgRoster() {
  const world = useLab((s) => s.world);
  const selectedId = useLab((s) => s.selectedId);
  const select = useLab((s) => s.select);

  return (
    <section id="catalogue" className="rounded-xl border border-border bg-surface">
      <div className="flex flex-wrap items-end justify-between gap-2 border-b border-border px-4 py-3">
        <div>
          <h2 className="font-display text-lg text-fg">Organisations</h2>
          <p className="text-xs text-muted">
            Organisations classified by function on the admitting source: producers, intermediates,
            and users.
          </p>
        </div>
      </div>
      <div className="grid gap-3 p-4 md:grid-cols-3">
        {ROLES.map((kind) => {
          const spec = ROLE_SPEC[kind];
          const members = world.agents
            .filter((a) => a.kind === kind)
            .sort((a, b) => a.name.localeCompare(b.name));
          const current = members.some((a) => a.id === selectedId) ? String(selectedId) : "";

          return (
            <label key={kind} className="block text-xs text-muted">
              {spec.title}
              <span className="ml-1 font-mono">({members.length})</span>
              <select
                className="mt-1 h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg"
                value={current}
                onChange={(e) => select(e.target.value === "" ? null : Number(e.target.value))}
              >
                <option value="">Select…</option>
                {members.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </label>
          );
        })}
      </div>
    </section>
  );
}
