import { articulationPoints, betweenness, bridges } from "@/lib/sim/structure";
import { useLab } from "@/lib/store";
import { formatNum } from "@/lib/utils";

export function StructurePanel() {
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);
  const bc = betweenness(world);
  const cuts = articulationPoints(world);
  const br = bridges(world);

  const ranked = world.agents
    .map((a) => ({ a, v: bc.get(a.id) ?? 0 }))
    .sort((x, y) => y.v - x.v)
    .slice(0, 8);

  return (
    <div className="space-y-5 text-sm">
      <p className="text-xs text-muted">
        Betweenness (Brandes, 2001) is the number of shortest paths that pass through an
        organisation. Articulation points are organisations whose deletion increases the number of
        connected components. Both quantities describe the public graph only.
      </p>
      <div>
        <h3 className="text-[10px] uppercase tracking-wide text-muted">Often on the shortest path</h3>
        <ol className="mt-2 space-y-1">
          {ranked.map(({ a, v }) => (
            <li key={a.id} className="flex justify-between gap-3">
              <button type="button" onClick={() => select(a.id)} className="text-left text-fg hover:text-accent">
                {a.name}
              </button>
              <span className="font-mono tabular-nums text-muted">{formatNum(v, 2)}</span>
            </li>
          ))}
        </ol>
      </div>
      <div>
        <h3 className="text-[10px] uppercase tracking-wide text-muted">Names that split the record</h3>
        {cuts.length === 0 ? (
          <p className="mt-2 text-muted">None.</p>
        ) : (
          <ul className="mt-2 space-y-1">
            {cuts.map((id) => {
              const a = world.agents.find((x) => x.id === id);
              return (
                <li key={id}>
                  <button type="button" onClick={() => select(id)} className="text-fg hover:text-accent">
                    {a?.name}
                  </button>
                  <span className="ml-2 text-xs text-subtle">
                    removal disconnects at least one cited component
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </div>
      <div>
        <h3 className="text-[10px] uppercase tracking-wide text-muted">Bridges</h3>
        {br.length === 0 ? (
          <p className="mt-2 text-muted">No bridge edges.</p>
        ) : (
          <ul className="mt-2 space-y-1">
            {br.map((e) => {
              const a = world.agents.find((x) => x.id === e.a);
              const b = world.agents.find((x) => x.id === e.b);
              return (
                <li key={`${e.a}-${e.b}`} className="text-fg">
                  {a?.name} — {b?.name}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
