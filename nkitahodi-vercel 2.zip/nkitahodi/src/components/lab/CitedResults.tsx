import { citedResults } from "@/lib/sim/results";
import { formatNum } from "@/lib/utils";
import { useLab } from "@/lib/store";

export function CitedResults() {
  const world = useLab((s) => s.world);
  const r = citedResults(world);

  return (
    <div>
      <h3 className="font-display text-lg text-fg">Quantities on the public graph</h3>
      <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted">
        Computed on the undirected cited graph. Host links record institutional containment.
        Project links record grants and jointly named programmes. Clustering is mean local
        transitivity. Mean geodesic distance is the average shortest-path length among reachable
        pairs. None of these quantities is an estimate of adoption.
      </p>

      <dl className="mt-5 grid gap-4 sm:grid-cols-3">
        <Stat k="Organisations" v={String(r.n)} />
        <Stat k="Links" v={String(r.m)} />
        <Stat k="Groups" v={String(r.components)} />
        <Stat k="Same-institution links" v={String(r.host)} />
        <Stat k="Project or grant links" v={String(r.project)} />
        <Stat
          k="Partners per name"
          v={`${formatNum(r.degree.mean, 2)} average`}
          s={`fewest ${r.degree.min} · middle ${r.degree.median} · most ${r.degree.max}`}
        />
        <Stat k="Clustering" v={formatNum(r.globalC, 3)} />
        <Stat k="Avg path length" v={formatNum(r.globalL, 3)} />
        <Stat
          k="Same two numbers, per name"
          v={`${formatNum(r.meanLocalC, 3)}, ${formatNum(r.meanLocalL, 3)}`}
          s={`${r.neighbourhoodsMeasured} names with enough partners.`}
        />
      </dl>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div>
          <h4 className="text-sm text-fg">Highest cited degree</h4>
          <ol className="mt-2 space-y-1 text-sm text-muted">
            {r.degree.top.map((x) => (
              <li key={x.id}>
                {x.name} <span className="font-mono text-xs">{x.d}</span>
              </li>
            ))}
          </ol>
          {r.degree.isolated.length > 0 && (
            <p className="mt-3 text-xs text-subtle">
              Isolated: {r.degree.isolated.join("; ")}.
            </p>
          )}
        </div>
        <div>
          <h4 className="text-sm text-fg">Betweenness (Brandes, 2001)</h4>
          <ol className="mt-2 space-y-1 text-sm text-muted">
            {r.betweenness.map((x) => (
              <li key={x.name}>
                {x.name} <span className="font-mono text-xs">{formatNum(x.v, 1)}</span>
              </li>
            ))}
          </ol>
          <p className="mt-3 text-xs text-subtle">
            Articulation points (removal increases the number of components):{" "}
            {r.cuts.length ? r.cuts.join("; ") : "none"}.
          </p>
        </div>
      </div>

      <div className="mt-6">
        <h4 className="text-sm text-fg">Language attestation</h4>
        <p className="mt-1 text-xs text-subtle">
          Organisations whose admitting source names the language. Counts are documentary, not
          demographic.
        </p>
        <ul className="mt-2 grid gap-2 sm:grid-cols-2">
          {r.langCounts.map((row) => (
            <li key={row.lang} className="text-sm text-muted">
              <span className="text-fg">{row.label}</span>{" "}
              <span className="font-mono text-xs">{row.n}</span>
              {row.source ? <span className="block text-xs text-subtle">{row.source}</span> : null}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-6">
        <h4 className="text-sm text-fg">Cited links by year of the source</h4>
        <table className="mt-2 w-full max-w-md text-left text-sm">
          <tbody>
            {r.years.map((y) => (
              <tr key={y.year}>
                <td className="py-0.5 font-mono text-fg">{y.year}</td>
                <td className="py-0.5 tabular-nums text-muted">{y.n}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Stat({ k, v, s }: { k: string; v: string; s?: string }) {
  return (
    <div className="rounded-md border border-border bg-elevated px-3 py-3">
      <dt className="text-[10px] uppercase tracking-wide text-muted">{k}</dt>
      <dd className="mt-1 font-display text-xl tabular-nums text-fg">{v}</dd>
      {s && <p className="mt-1 text-xs text-subtle">{s}</p>}
    </div>
  );
}
