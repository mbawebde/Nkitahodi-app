import { ChevronLeft, ChevronRight } from "lucide-react";
import { LANGUAGE_LABEL } from "@/lib/sim/types";
import { useLab } from "@/lib/store";

const STEPS = [
  {
    id: "catalogue",
    n: "1",
    title: "Organisations",
    hint: "Pick a name by role.",
  },
  {
    id: "map",
    n: "2",
    title: "Network",
    hint: "Circle, clusters, or region.",
  },
  {
    id: "story",
    n: "3",
    title: "Details",
    hint: "Partners, clustering, and sources.",
  },
  {
    id: "analysis",
    n: "4",
    title: "Analysis",
    hint: "Languages, years, and who sits in the middle.",
  },
];

export function GuideNav() {
  const world = useLab((s) => s.world);
  const selectedId = useLab((s) => s.selectedId);
  const focusLang = useLab((s) => s.focusLang);
  const select = useLab((s) => s.select);
  const selected = world.agents.find((a) => a.id === selectedId);

  const pool = world.agents.filter((a) => !focusLang || a.languages.includes(focusLang));
  const idx = pool.findIndex((a) => a.id === selectedId);

  const go = (dir: -1 | 1) => {
    if (!pool.length) return;
    const next = idx < 0 ? 0 : (idx + dir + pool.length) % pool.length;
    select(pool[next]!.id);
    document.getElementById("story")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  };

  return (
    <nav
      aria-label="Prototype navigation"
      className="sticky top-0 z-20 border-b border-border bg-surface/95 backdrop-blur-sm"
    >
      <div className="mx-auto flex max-w-[1400px] flex-col gap-3 px-4 py-3 md:flex-row md:items-center md:justify-between md:px-6">
        <ol className="flex min-w-0 flex-1 flex-wrap gap-x-8 gap-y-2">
          {STEPS.map((s) => (
            <li key={s.id}>
              <a href={`#${s.id}`} className="group block">
                <span className="font-mono text-xs text-mark">{s.n}</span>
                <span className="ml-2 text-sm text-fg group-hover:text-accent">{s.title}</span>
                <span className="mt-0.5 block text-xs text-subtle">{s.hint}</span>
              </a>
            </li>
          ))}
        </ol>
        <div className="flex items-center gap-2">
          <p className="max-w-56 truncate text-xs text-muted">
            {focusLang ? LANGUAGE_LABEL[focusLang] : "All documented languages"}
            {selected ? ` · ${selected.name}` : ""}
          </p>
          <button
            type="button"
            aria-label="Previous organisation"
            onClick={() => go(-1)}
            className="flex size-10 items-center justify-center rounded-md border border-border text-fg"
          >
            <ChevronLeft className="size-4" />
          </button>
          <button
            type="button"
            aria-label="Next organisation"
            onClick={() => go(1)}
            className="flex size-10 items-center justify-center rounded-md border border-border text-fg"
          >
            <ChevronRight className="size-4" />
          </button>
        </div>
      </div>
    </nav>
  );
}
