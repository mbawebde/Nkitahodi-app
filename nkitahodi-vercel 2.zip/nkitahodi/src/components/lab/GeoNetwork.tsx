import { useEffect, useRef } from "react";
import { GEO_BLURB, GEO_LABEL, GEO_ZONES, zoneCounts, zoneFlows, zoneOf, type GeoZone } from "@/lib/sim/geo";
import type { Agent } from "@/lib/sim/types";
import { useLab } from "@/lib/store";

const BOX: Record<GeoZone, { x: number; y: number; w: number; h: number }> = {
  abroad: { x: 40, y: 24, w: 640, h: 110 },
  ashanti: { x: 220, y: 160, w: 280, h: 150 },
  central: { x: 40, y: 330, w: 240, h: 130 },
  accra: { x: 320, y: 330, w: 360, h: 130 },
};

function placeInBox(agents: Agent[], zone: GeoZone) {
  const box = BOX[zone];
  const members = agents.filter((a) => zoneOf(a) === zone);
  return members.map((a, i) => {
    const n = Math.max(1, members.length);
    const cols = Math.ceil(Math.sqrt(n));
    const row = Math.floor(i / cols);
    const col = i % cols;
    const rows = Math.ceil(n / cols);
    return {
      a,
      x: box.x + 28 + (col + 0.5) * ((box.w - 40) / cols),
      y: box.y + 36 + (row + 0.5) * ((box.h - 44) / rows),
    };
  });
}

export function GeoNetwork({ embedded = false }: { embedded?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const world = useLab((s) => s.world);
  const select = useLab((s) => s.select);
  const counts = zoneCounts(world);
  const flows = zoneFlows(world);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let w = 0;
    let h = 0;
    let dpr = 1;

    const token = (name: string, fallback: string) =>
      getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = wrap.clientWidth;
      h = wrap.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const allPos = (agents: Agent[]) => GEO_ZONES.flatMap((z) => placeInBox(agents, z));

    const draw = () => {
      const { world, selectedId: sid, focusLang } = useLab.getState();
      const fill = token("--color-canvas", "#ffffff");
      const fg = token("--color-fg", "#16140f");
      const mark = token("--color-mark", "#c4a574");
      const muted = token("--color-muted", "#5c5954");
      const scale = Math.min(w / 720, h / 500);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = fill;
      ctx.fillRect(0, 0, w, h);
      ctx.save();
      ctx.translate((w - 720 * scale) / 2, (h - 500 * scale) / 2);
      ctx.scale(scale, scale);

      for (const z of GEO_ZONES) {
        const b = BOX[z];
        ctx.strokeStyle = "rgba(236,234,228,0.12)";
        ctx.strokeRect(b.x, b.y, b.w, b.h);
        ctx.fillStyle = muted;
        ctx.font = "11px IBM Plex Sans, sans-serif";
        ctx.fillText(`${GEO_LABEL[z]}  ${counts[z]}`, b.x + 10, b.y + 18);
      }

      const placed = allPos(world.agents);
      const byId = new Map(placed.map((p) => [p.a.id, p]));

      for (const e of world.edges) {
        if (!e.cited) continue;
        const a = byId.get(e.a);
        const b = byId.get(e.b);
        if (!a || !b) continue;
        const hot = sid != null && (e.a === sid || e.b === sid);
        ctx.strokeStyle = hot ? mark : fg;
        ctx.globalAlpha = hot ? 0.9 : 0.12;
        ctx.lineWidth = hot ? 1.8 : 1;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      for (const p of placed) {
        const match = !focusLang || p.a.languages.includes(focusLang);
        const hot = sid === p.a.id;
        ctx.globalAlpha = focusLang && !match ? 0.15 : 1;
        ctx.fillStyle = hot ? mark : fg;
        ctx.beginPath();
        if (p.a.kind === "producer") ctx.rect(p.x - 5, p.y - 5, 10, 10);
        else if (p.a.kind === "intermediary") {
          ctx.moveTo(p.x, p.y - 6);
          ctx.lineTo(p.x + 6, p.y);
          ctx.lineTo(p.x, p.y + 6);
          ctx.lineTo(p.x - 6, p.y);
          ctx.closePath();
        } else ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
        ctx.fill();
        if (hot || (focusLang && match)) {
          ctx.fillStyle = mark;
          ctx.font = "10px IBM Plex Sans, sans-serif";
          ctx.fillText(p.a.name.length > 22 ? `${p.a.name.slice(0, 20)}…` : p.a.name, p.x + 8, p.y + 3);
        }
        ctx.globalAlpha = 1;
      }
      ctx.restore();
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    const onClick = (ev: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const scale = Math.min(w / 720, h / 500);
      const ox = (w - 720 * scale) / 2;
      const oy = (h - 500 * scale) / 2;
      const x = (ev.clientX - rect.left - ox) / scale;
      const y = (ev.clientY - rect.top - oy) / scale;
      const { world, selectedId } = useLab.getState();
      let best: number | null = null;
      let bestD = 28;
      for (const p of allPos(world.agents)) {
        const d = Math.hypot(p.x - x, p.y - y);
        if (d < bestD) {
          bestD = d;
          best = p.a.id;
        }
      }
      if (best != null) select(best === selectedId ? null : best);
    };
    canvas.addEventListener("click", onClick);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("click", onClick);
    };
  }, [select, world]);

  const body = (
    <>
      <div ref={wrapRef} className={embedded ? "relative h-[420px] md:h-[520px]" : "relative h-[380px] md:h-[460px]"}>
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      </div>
      <ul className="grid gap-3 border-t border-border px-4 py-3 sm:grid-cols-2">
        {GEO_ZONES.map((z) => (
          <li key={z}>
            <p className="text-sm text-fg">
              {GEO_LABEL[z]}{" "}
              <span className="font-mono text-xs text-muted">{counts[z]}</span>
            </p>
            <p className="mt-1 text-xs text-subtle">{GEO_BLURB[z]}</p>
          </li>
        ))}
      </ul>
      <ul className="border-t border-border px-4 py-3 text-xs text-subtle">
        {flows.map((f) => (
          <li key={`${f.a}-${f.b}`}>
            {GEO_LABEL[f.a]} — {GEO_LABEL[f.b]}: {f.n} link{f.n === 1 ? "" : "s"}
          </li>
        ))}
      </ul>
    </>
  );

  if (embedded) return body;

  return (
    <section id="geography" className="rounded-xl border border-border bg-elevated">
      <div className="border-b border-border px-4 py-3">
        <h2 className="font-display text-lg text-fg">Geographic projection</h2>
        <p className="text-sm text-muted">
          The same public links, placed by region.
        </p>
      </div>
      {body}
    </section>
  );
}
