import {
  downloadText,
  edgesCsv,
  graphMl,
  methodsNote,
  networkJson,
  nodesCsv,
} from "@/lib/sim/export";
import { useLab } from "@/lib/store";

export function ExportView() {
  const world = useLab((s) => s.world);

  return (
    <section id="export" className="mx-auto max-w-3xl rounded-xl border border-border bg-surface px-5 py-8">
      <h2 className="font-display text-2xl text-fg">Export the record</h2>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        These files reproduce the public graph shown in Network and Analysis. The organisation
        list includes role and cited degree. The link list includes tie type, date, evidence
        string, and source. JSON is a complete archive. GraphML is an undirected graph for Gephi
        or NetworkX. The accompanying note states the admission rule and the definition of each
        metric. No simulated observations are included.
      </p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <ExportCard
          title="Organisations CSV"
          hint="Names, roles, and partner counts"
          onClick={() => downloadText("nkitahodi-nodes.csv", nodesCsv(world), "text/csv")}
        />
        <ExportCard
          title="Links CSV"
          hint="Each public link with its source"
          onClick={() => downloadText("nkitahodi-edges.csv", edgesCsv(world), "text/csv")}
        />
        <ExportCard
          title="JSON"
          hint="Full archive of names and links"
          onClick={() => downloadText("nkitahodi-network.json", networkJson(world), "application/json")}
        />
        <ExportCard
          title="GraphML"
          hint="Open in Gephi or NetworkX"
          onClick={() => downloadText("nkitahodi-network.graphml", graphMl(world), "application/xml")}
        />
        <ExportCard
          title="How it works"
          hint="Plain note on what is included"
          onClick={() => downloadText("nkitahodi-how-it-works.txt", methodsNote(world))}
        />
      </div>
    </section>
  );
}

function ExportCard({ title, hint, onClick }: { title: string; hint: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-lg border border-border bg-elevated p-4 text-left hover:border-border-strong"
    >
      <p className="font-display text-lg text-fg">{title}</p>
      <p className="mt-1 text-xs text-muted">{hint}</p>
    </button>
  );
}
