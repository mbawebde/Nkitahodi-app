import type { World } from "./types";

export function shortestPath(world: World, start: number, end: number, includeHost = true): number[] | null {
  if (start === end) return [start];
  const adj = new Map<number, number[]>();
  for (const a of world.agents) adj.set(a.id, []);
  for (const e of world.edges) {
    if (!e.cited) continue;
    if (!includeHost && e.tie === "host") continue;
    adj.get(e.a)?.push(e.b);
    adj.get(e.b)?.push(e.a);
  }
  const prev = new Map<number, number>();
  const q = [start];
  const seen = new Set([start]);
  while (q.length) {
    const cur = q.shift()!;
    if (cur === end) {
      const path = [end];
      let p = end;
      while (p !== start) {
        p = prev.get(p)!;
        path.push(p);
      }
      return path.reverse();
    }
    for (const n of adj.get(cur) ?? []) {
      if (seen.has(n)) continue;
      seen.add(n);
      prev.set(n, cur);
      q.push(n);
    }
  }
  return null;
}

export function componentOf(world: World, start: number, includeHost = true): Set<number> {
  const adj = new Map<number, number[]>();
  for (const a of world.agents) adj.set(a.id, []);
  for (const e of world.edges) {
    if (!e.cited) continue;
    if (!includeHost && e.tie === "host") continue;
    adj.get(e.a)?.push(e.b);
    adj.get(e.b)?.push(e.a);
  }
  const seen = new Set<number>();
  const q = [start];
  seen.add(start);
  while (q.length) {
    const cur = q.shift()!;
    for (const n of adj.get(cur) ?? []) {
      if (seen.has(n)) continue;
      seen.add(n);
      q.push(n);
    }
  }
  return seen;
}
