import { clusteringCoefficient, averagePathLength } from "./network";
import { mulberry32 } from "./rng";
import type { Edge, RewirePoint, RewireReport, World } from "./types";

function key(a: number, b: number) {
  return a < b ? `${a}-${b}` : `${b}-${a}`;
}

function edgeSet(edges: Edge[]) {
  return new Set(edges.map((e) => key(e.a, e.b)));
}

export function structurePoint(world: World, x: number): RewirePoint {
  return {
    x,
    clustering: clusteringCoefficient(world),
    avgPath: averagePathLength(world),
  };
}

function pickNewPartner(
  keep: number,
  drop: number,
  ids: number[],
  existing: Set<string>,
  rng: () => number,
) {
  const candidates = ids.filter((id) => id !== keep && id !== drop && !existing.has(key(keep, id)));
  if (!candidates.length) return null;
  return candidates[Math.floor(rng() * candidates.length)]!;
}

function applyRewire(world: World, index: number, rng: () => number): { world: World; report: RewireReport } | null {
  const pick = world.edges[index];
  if (!pick?.cited) return null;
  const existing = edgeSet(world.edges);
  const ids = world.agents.map((a) => a.id);
  const flip = rng() < 0.5;
  const keep = flip ? pick.a : pick.b;
  const drop = flip ? pick.b : pick.a;
  const nextId = pickNewPartner(keep, drop, ids, existing, rng);
  if (nextId == null) return null;

  const name = (id: number) => world.agents.find((a) => a.id === id)?.name ?? "?";
  const nextEdge: Edge = {
    a: Math.min(keep, nextId),
    b: Math.max(keep, nextId),
    weight: pick.weight,
    cited: false,
    replaced: {
      a: pick.a,
      b: pick.b,
      evidence: pick.evidence,
      source: pick.source,
      href: pick.href,
    },
  };

  const edges = world.edges.slice();
  edges[index] = nextEdge;
  const report: RewireReport = {
    kept: name(keep),
    dropped: name(drop),
    joined: name(nextId),
    citation: pick.evidence,
    source: pick.source,
  };
  const events = [
    {
      tick: world.tick,
      text: `Broke cited thread ${name(pick.a)} — ${name(pick.b)}. Joined ${name(keep)} — ${name(nextId)} (not in the public record).`,
      source: "sim" as const,
      evidence: pick.source,
      orgIds: [keep, drop, nextId],
    },
    ...world.events,
  ];
  return { world: { ...world, edges, events }, report };
}

export function rewireOneEdge(
  world: World,
  seed: number,
  preferId?: number | null,
): { world: World; report: RewireReport | null } {
  const rng = mulberry32(seed);
  const cited = world.edges
    .map((e, i) => i)
    .filter((i) => {
      const e = world.edges[i]!;
      return e.cited && (preferId == null || e.a === preferId || e.b === preferId);
    });
  const pool = cited.length ? cited : world.edges.map((e, i) => i).filter((i) => world.edges[i]!.cited);
  if (!pool.length) return { world, report: null };
  const index = pool[Math.floor(rng() * pool.length)]!;
  const next = applyRewire(world, index, rng);
  return next ?? { world, report: null };
}

export function rewireCitedWithProbability(
  world: World,
  p: number,
  seed: number,
): { world: World; broken: number; report: RewireReport | null } {
  const rng = mulberry32(seed);
  let current: World = { ...world, edges: world.edges.map((e) => ({ ...e })) };
  let broken = 0;
  let last: RewireReport | null = null;
  const indexes = current.edges.map((e, i) => i).filter((i) => current.edges[i]!.cited);
  for (const i of indexes) {
    if (rng() >= p) continue;
    const live = current.edges.findIndex(
      (e) => e.cited && e.a === world.edges[i]!.a && e.b === world.edges[i]!.b,
    );
    const target = live >= 0 ? live : i;
    const step = applyRewire(current, target, rng);
    if (!step) continue;
    current = step.world;
    last = step.report;
    broken++;
  }
  return { world: current, broken, report: last };
}

export function citedShare(world: World) {
  const n = world.edges.length || 1;
  const cited = world.edges.filter((e) => e.cited).length;
  return { cited, experimental: n - cited, fraction: (n - cited) / n };
}
