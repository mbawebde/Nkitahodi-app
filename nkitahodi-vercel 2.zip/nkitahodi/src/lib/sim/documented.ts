import { citeUrl } from "./citations";
import { languagesOf } from "./languageCoverage";
import { placeClusters } from "./layout";
import type { Agent, AgentKind, Edge, Language, World } from "./types";

interface NodeSeed {
  name: string;
  kind: AgentKind;
  region: string;
  sector: string;
  languages: Language[];
  isHub?: boolean;
  note: string;
}

interface EdgeSeed {
  a: string;
  b: string;
  evidence: string;
  source: string;
  date?: string;
  tie?: "host" | "project";
}

const NODES: NodeSeed[] = [
  {
    name: "University of Ghana",
    kind: "producer",
    region: "Greater Accra",
    sector: "research",
    languages: ["akan", "ewe", "dagbani", "dagaare", "ikposo"],
    isHub: true,
    note: "WAXAL collection lead for Ghanaian languages. Lead institution on tɛkyerɛma pa (Nov 2024).",
  },
  {
    name: "UG HCI Lab",
    kind: "producer",
    region: "Greater Accra",
    sector: "research",
    languages: ["akan", "ewe", "dagbani", "dagaare", "ikposo"],
    isHub: true,
    note: "DCS HCI Lab. UGSpeechData (~5,000h). Hosts tɛkyerɛma pa non-standard-speech work.",
  },
  {
    name: "KNUST",
    kind: "producer",
    region: "Ashanti",
    sector: "research",
    languages: ["akan"],
    isHub: true,
    note: "Hosts RAIL. CAD $1 million AI4D grant announced 30 Jan 2022.",
  },
  {
    name: "RAIL KNUST",
    kind: "producer",
    region: "Ashanti",
    sector: "research",
    languages: ["akan"],
    isHub: true,
    note: "KNUST KEEP, 30 Jan 2022: CAD $1 million under AI4D Multidisciplinary Labs (IDRC). PI thanks IDRC and GIZ for setup.",
  },
  {
    name: "University of Cape Coast",
    kind: "producer",
    region: "Central",
    sector: "research",
    languages: ["akan", "ewe", "ga", "fante", "kusaal"],
    note: "Department of Mathematics authors on GhanaNLP Parallel Corpora (Twi, Fante, Ewe, Ga, Kusaal).",
  },
  {
    name: "GhanaNLP",
    kind: "producer",
    region: "Greater Accra",
    sector: "language-ai",
    languages: ["akan", "ewe", "ga", "fante", "kusaal"],
    isHub: true,
    note: "Open community. Parallel corpora for Twi, Fante, Ewe, Ga and Kusaal. Funded by Google LLC only (arXiv:2603.13793).",
  },
  {
    name: "Khaya AI",
    kind: "producer",
    region: "Greater Accra",
    sector: "language-ai",
    languages: ["akan", "ewe", "ga", "fante", "kusaal"],
    note: "Product line from GhanaNLP and Algorine. Trained on those Ghanaian-language corpora.",
  },
  {
    name: "Algorine",
    kind: "producer",
    region: "Greater Accra",
    sector: "language-ai",
    languages: ["akan", "ewe", "ga", "fante", "kusaal"],
    note: "With GhanaNLP released the first Ghanaian-language ML translation app (2021).",
  },
  {
    name: "Google",
    kind: "producer",
    region: "Continental",
    sector: "research",
    languages: ["akan", "ewe", "dagbani", "dagaare", "ikposo"],
    isHub: true,
    note: "Google Research Africa: WAXAL and tɛkyerɛma pa. Google LLC: sole funder of GhanaNLP corpora (arXiv:2603.13793).",
  },
  {
    name: "UCL GDI Hub",
    kind: "producer",
    region: "International",
    sector: "inclusion",
    languages: ["akan", "ewe", "dagbani", "dagaare", "ikposo"],
    note: "AT2030 partner on tɛkyerɛma pa. Project supported by a $40,000 Google grant (GDI Hub / CDLI, Nov 2024).",
  },
  {
    name: "Makerere University",
    kind: "producer",
    region: "Uganda",
    sector: "research",
    languages: ["akan"],
    note: "WAXAL partner. Google names Makerere and UG as collection leads for 13 languages combined.",
  },
  {
    name: "Digital Umuganda",
    kind: "producer",
    region: "Rwanda",
    sector: "language-ai",
    languages: ["akan"],
    note: "WAXAL consortium partner for ASR collection.",
  },
  {
    name: "IDRC",
    kind: "producer",
    region: "International",
    sector: "funding",
    languages: ["akan"],
    note: "Awarded CAD $1 million to KNUST (30 Jan 2022) to establish RAIL under AI4D Multidisciplinary Labs.",
  },
  {
    name: "GIZ / DTC Ghana",
    kind: "producer",
    region: "Greater Accra",
    sector: "funding",
    languages: ["akan"],
    note: "Named by KNUST as joint funder of RAIL setup with IDRC. Crop-disease challenge with RAIL and Zindi. Named on the National AI Strategy.",
  },
  {
    name: "Zindi",
    kind: "intermediary",
    region: "Continental",
    sector: "industry",
    languages: ["akan"],
    note: "Hosted the Ghana Crop Disease Detection Challenge with RAIL and GIZ (26 Nov 2024).",
  },
  {
    name: "MoFA / PPRSD",
    kind: "intermediary",
    region: "Greater Accra",
    sector: "agriculture",
    languages: ["akan", "ewe", "dagbani"],
    note: "Named collaborator on RAIL’s crop-disease toolbox.",
  },
  {
    name: "Local farmers (PPRSD pilots)",
    kind: "user",
    region: "Ashanti",
    sector: "farming",
    languages: ["akan"],
    note: "Named field collaborators on the RAIL / PPRSD toolbox. Not a registered firm.",
  },
  {
    name: "KNUST Disability Studies",
    kind: "user",
    region: "Ashanti",
    sector: "inclusion",
    languages: ["akan"],
    note: "RAIL stakeholder event 29 Nov 2024.",
  },
  {
    name: "MoCDTI",
    kind: "producer",
    region: "Greater Accra",
    sector: "governance",
    languages: ["akan", "ewe", "dagbani"],
    isHub: true,
    note: "Launched National AI Strategy 24 Apr 2026.",
  },
  {
    name: "NITA",
    kind: "producer",
    region: "Greater Accra",
    sector: "governance",
    languages: ["akan"],
    note: "Named implementation body of the National AI Strategy (moc.gov.gh 24 Apr 2026).",
  },
  {
    name: "Data Protection Commission",
    kind: "producer",
    region: "Greater Accra",
    sector: "governance",
    languages: ["akan"],
    note: "Named implementation institution (moc.gov.gh 24 Apr 2026).",
  },
  {
    name: "Cyber Security Authority",
    kind: "producer",
    region: "Greater Accra",
    sector: "governance",
    languages: ["akan"],
    note: "Named implementation institution (moc.gov.gh 24 Apr 2026).",
  },
  {
    name: "UNDP Ghana",
    kind: "producer",
    region: "Greater Accra",
    sector: "funding",
    languages: ["akan"],
    note: "Named international implementation partner of the National AI Strategy.",
  },
  {
    name: "UNESCO",
    kind: "producer",
    region: "International",
    sector: "funding",
    languages: ["akan"],
    note: "Named international implementation partner of the National AI Strategy.",
  },
];

const EDGES: EdgeSeed[] = [
  {
    a: "UG HCI Lab",
    b: "University of Ghana",
    evidence: "Lab is in the Department of Computer Science, University of Ghana.",
    source: "github.com/HCI-LAB-UGSPEECHDATA",
    date: "2024",
    tie: "host",
  },
  {
    a: "UG HCI Lab",
    b: "Google",
    evidence: "HCI Lab lists WAXAL (UGSpeechData) as a Google-funded project. ScienceDB DOI 10.57760/sciencedb.22298.",
    source: "doi:10.57760/sciencedb.22298",
    date: "2024",
  },
  {
    a: "University of Ghana",
    b: "Google",
    evidence: "Google Research WAXAL blog: UG collected ASR/TTS for Ghanaian languages.",
    source: "research.google/blog/waxal",
    date: "2026-02",
  },
  {
    a: "University of Ghana",
    b: "Makerere University",
    evidence: "Google Africa blog (2 Feb 2026): Makerere and UG led collection for 13 languages combined.",
    source: "blog.google WAXAL 2 Feb 2026",
    date: "2026-02-02",
  },
  {
    a: "University of Ghana",
    b: "Digital Umuganda",
    evidence: "Named as WAXAL consortium partners on the Google Research blog.",
    source: "research.google/blog/waxal",
    date: "2026-02",
  },
  {
    a: "Google",
    b: "Makerere University",
    evidence: "WAXAL: Makerere collected ASR and TTS for multiple languages.",
    source: "research.google/blog/waxal",
    date: "2026-02",
  },
  {
    a: "Google",
    b: "Digital Umuganda",
    evidence: "WAXAL: Digital Umuganda led ASR collection for several languages.",
    source: "research.google/blog/waxal",
    date: "2026-02",
  },
  {
    a: "UG HCI Lab",
    b: "UCL GDI Hub",
    evidence:
      "tɛkyerɛma pa (Good Tongue), Nov 2024: UG, Google Research Africa and UCL GDI Hub (AT2030). $40,000 Google grant.",
    source: "disabilityinnovation.com 1 Nov 2024",
    date: "2024-11-01",
  },
  {
    a: "University of Ghana",
    b: "UCL GDI Hub",
    evidence: "Same announcement: University of Ghana is project lead.",
    source: "disabilityinnovation.com 1 Nov 2024",
    date: "2024-11-01",
  },
  {
    a: "Google",
    b: "UCL GDI Hub",
    evidence: "Same announcement: Google Research Africa collaborates; $40,000 Google grant.",
    source: "disabilityinnovation.com 1 Nov 2024",
    date: "2024-11-01",
  },
  {
    a: "GhanaNLP",
    b: "Khaya AI",
    evidence: "Khaya grew from GhanaNLP; shared 2026 corpora paper authors.",
    source: "khaya.ai/about-us",
    date: "2021-07-13",
  },
  {
    a: "GhanaNLP",
    b: "Algorine",
    evidence: "ghananlp.org: Khaya Translator Web App, company Algorine & GhanaNLP, 13 Jul 2021.",
    source: "ghananlp.org/project/translator-webapp",
    date: "2021-07-13",
  },
  {
    a: "Algorine",
    b: "Khaya AI",
    evidence: "khaya.ai: GhanaNLP and Algorine released the first Ghanaian-language AI translation app (2021).",
    source: "khaya.ai/about-us",
    date: "2021-07-13",
  },
  {
    a: "GhanaNLP",
    b: "University of Cape Coast",
    evidence: "arXiv:2603.13793 — Moore, Department of Mathematics, University of Cape Coast, co-author.",
    source: "arXiv:2603.13793",
    date: "2026-03",
  },
  {
    a: "GhanaNLP",
    b: "Google",
    evidence:
      "arXiv:2603.13793 funding statement: supported by Google LLC through a single-source model to the GhanaNLP volunteer group. No additional institutional funding.",
    source: "arXiv:2603.13793",
    date: "2026-03",
  },
  {
    a: "RAIL KNUST",
    b: "KNUST",
    evidence: "RAIL is hosted at KNUST. CAD $1 million AI4D grant to the College of Engineering, 30 Jan 2022.",
    source: "keep.knust.edu.gh 30 Jan 2022",
    date: "2022-01-30",
    tie: "host",
  },
  {
    a: "RAIL KNUST",
    b: "IDRC",
    evidence:
      "KNUST KEEP, 30 Jan 2022: CAD $1 million from IDRC under the AI4D Africa Multidisciplinary Labs project.",
    source: "keep.knust.edu.gh 30 Jan 2022",
    date: "2022-01-30",
  },
  {
    a: "RAIL KNUST",
    b: "GIZ / DTC Ghana",
    evidence:
      "KNUST KEEP: PI thanks IDRC and GIZ for jointly funding lab setup. Later crop-disease challenge with Zindi, GIZ, DTC and FAIR Forward (26 Nov 2024).",
    source: "keep.knust.edu.gh 30 Jan 2022",
    date: "2022-01-30",
  },
  {
    a: "RAIL KNUST",
    b: "MoFA / PPRSD",
    evidence: "Crop Disease Detection Toolbox developed with PPRSD and local farmers.",
    source: "ai4d.ai RAIL impact 30 Jan 2025",
    date: "2025-01-30",
  },
  {
    a: "RAIL KNUST",
    b: "Local farmers (PPRSD pilots)",
    evidence: "Same toolbox: application developed with farmers as named end-users.",
    source: "bmz-digital.global 25 Mar 2025",
    date: "2025-03-25",
  },
  {
    a: "RAIL KNUST",
    b: "Zindi",
    evidence: "Ghana Crop Disease Detection Challenge on Zindi, 26 Nov 2024.",
    source: "ai4d.ai RAIL impact 30 Jan 2025",
    date: "2024-11-26",
  },
  {
    a: "Zindi",
    b: "GIZ / DTC Ghana",
    evidence: "Same challenge consortium: Zindi, GIZ, DTC, FAIR Forward.",
    source: "ai4d.ai RAIL impact 30 Jan 2025",
    date: "2024-11-26",
  },
  {
    a: "RAIL KNUST",
    b: "KNUST Disability Studies",
    evidence: "Stakeholder event 29 Nov 2024 with the Dept. of Health Promotion and Disability Studies.",
    source: "rail.knust.edu.gh 9 Dec 2024",
    date: "2024-11-29",
  },
  {
    a: "MoCDTI",
    b: "RAIL KNUST",
    evidence: "National AI Strategy implementation names KNUST Responsible AI Lab.",
    source: "moc.gov.gh 24 Apr 2026",
    date: "2026-04-24",
  },
  {
    a: "MoCDTI",
    b: "GIZ / DTC Ghana",
    evidence: "Strategy implementation partners include GIZ.",
    source: "moc.gov.gh 24 Apr 2026",
    date: "2026-04-24",
  },
  {
    a: "MoCDTI",
    b: "UNDP Ghana",
    evidence: "UNDP named as an international implementation partner.",
    source: "moc.gov.gh 24 Apr 2026",
    date: "2026-04-24",
  },
  {
    a: "MoCDTI",
    b: "UNESCO",
    evidence: "UNESCO named as an international implementation partner.",
    source: "moc.gov.gh 24 Apr 2026",
    date: "2026-04-24",
  },
  {
    a: "MoCDTI",
    b: "NITA",
    evidence: "NITA named as a domestic implementation institution.",
    source: "moc.gov.gh 24 Apr 2026",
    date: "2026-04-24",
  },
  {
    a: "MoCDTI",
    b: "Data Protection Commission",
    evidence: "Named with NITA and CSA as implementation institutions.",
    source: "moc.gov.gh 24 Apr 2026",
    date: "2026-04-24",
  },
  {
    a: "MoCDTI",
    b: "Cyber Security Authority",
    evidence: "Named with NITA and DPC as implementation institutions.",
    source: "moc.gov.gh 24 Apr 2026",
    date: "2026-04-24",
  },
];

function layout(i: number, n: number) {
  const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
  return { x: Math.cos(angle) * 210, y: Math.sin(angle) * 210 };
}

export function createDocumentedWorld(): World {
  const agents: Agent[] = NODES.map((n, i) => {
    const p = layout(i, NODES.length);
    return {
      id: i,
      kind: n.kind,
      name: n.name,
      region: n.region,
      x: p.x,
      y: p.y,
      vx: 0,
      vy: 0,
      knowledge: 0,
      adopted: false,
      compute: 0,
      languages: languagesOf(n.name),
      sector: n.sector,
      isHub: Boolean(n.isHub),
      note: n.note,
    };
  });

  const placed = placeClusters(agents);
  const byName = new Map(placed.map((a) => [a.name, a.id]));
  const edges: Edge[] = [];
  const seen = new Set<string>();

  for (const e of EDGES) {
    const ai = byName.get(e.a);
    const bi = byName.get(e.b);
    if (ai == null || bi == null || ai === bi) continue;
    const lo = Math.min(ai, bi);
    const hi = Math.max(ai, bi);
    const key = `${lo}-${hi}`;
    if (seen.has(key)) continue;
    seen.add(key);
    edges.push({
      a: lo,
      b: hi,
      weight: 1,
      evidence: e.evidence,
      source: e.source,
      href: citeUrl(e.source),
      date: e.date,
      tie: e.tie ?? "project",
      cited: true,
    });
  }

  return {
    agents: placed,
    edges,
    particles: [],
    events: [
      {
        tick: 0,
        text: `Documented graph: ${agents.length} organisations and ${edges.length} cited edges.`,
      },
    ],
    tick: 0,
    transfers: 0,
    nextParticle: 1,
    documented: true,
  };
}

export const DOCUMENTED_COUNTS = {
  nodes: NODES.length,
  edges: EDGES.length,
};
