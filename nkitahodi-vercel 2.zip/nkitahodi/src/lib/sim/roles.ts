import type { AgentKind } from "./types";

export const ROLE_SPEC: Record<
  AgentKind,
  { title: string; who: string; does: string }
> = {
  producer: {
    title: "Producers",
    who: "Universities, laboratories, and industry",
    does:
      "Producers generate or finance language resources and models. Each documented tie constitutes a pathway for knowledge transfer, the volume of which scales with cited degree.",
  },
  intermediary: {
    title: "Intermediates",
    who: "Organisations that translate laboratory outputs into applications",
    does:
      "Intermediates deploy models or platforms named on the public record. Adoption is recorded only when a source names the organisation in that role; it is not inferred from product availability.",
  },
  user: {
    title: "Users",
    who: "Named communities and institutional end users",
    does:
      "Users are communities or offices of intended adoption named in an admitting source. Presence on this graph is a documentary fact, not a measure of uptake.",
  },
};
