import { averagePathLength, clusteringCoefficient } from "./network";
import type { AgentKind, World } from "./types";

/** Cited neighbourhood only: the node plus organisations on a public thread. */
export function collaborationOf(world: World, id: number) {
  const memberIds = new Set<number>([id]);
  for (const e of world.edges) {
    if (!e.cited) continue;
    if (e.a === id) memberIds.add(e.b);
    if (e.b === id) memberIds.add(e.a);
  }

  const agents = world.agents.filter((a) => memberIds.has(a.id));
  const edges = world.edges.filter((e) => e.cited && memberIds.has(e.a) && memberIds.has(e.b));
  const sub: World = { ...world, agents, edges };

  const counts: Record<AgentKind, number> = { producer: 0, intermediary: 0, user: 0 };
  for (const a of agents) counts[a.kind]++;

  const experimental = world.edges.filter((e) => !e.cited && (e.a === id || e.b === id)).length;
  const tooSmall = agents.length < 3;

  return {
    size: agents.length,
    threads: edges.length,
    cited: edges.length,
    clustering: tooSmall ? null : clusteringCoefficient(sub),
    avgPath: agents.length < 2 ? null : averagePathLength(sub),
    counts,
    experimental,
    tooSmall,
  };
}
