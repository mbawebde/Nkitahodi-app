import { chance, mulberry32, pick } from "./rng";
import type { Agent, AgentKind, Edge, Language, World } from "./types";
import { LANGUAGES } from "./types";

const REGIONS = [
  "Greater Accra",
  "Ashanti",
  "Northern",
  "Volta",
  "Upper West",
  "Central",
  "Eastern",
  "Western",
];

const UNI_NAMES = [
  "University of Ghana",
  "KNUST",
  "UCC",
  "UEW",
  "UDS",
  "UG HCI Lab",
  "GTEC",
  "CSIR-STEPRI",
];

const SME_NAMES = [
  "Tamale grain cooperative",
  "Kejetia traders union",
  "Volta river fishers",
  "Cape Coast cassava mill",
  "Wa shea collective",
  "Kumasi kente workshop",
  "Tema spare-parts yard",
  "Ho market association",
  "Bolgatanga basket makers",
  "Takoradi cold-store",
  "Sunyani cocoa depot",
  "Kasoa poultry cluster",
  "Navrongo seed bank",
  "Aflao border traders",
  "Techiman yam market",
];

const TEACHER_NAMES = [
  "Accra teacher-training",
  "Tamale college of education",
  "Winneba language unit",
  "Hohoe basic cluster",
  "Wa circuit supervisors",
];

function languageForRegion(region: string): Language[] {
  if (region === "Volta") return ["ewe", "ikposo"];
  if (region === "Northern") return ["dagbani", "akan"];
  if (region === "Upper West") return ["dagaare", "dagbani"];
  if (region === "Ashanti" || region === "Central" || region === "Eastern")
    return ["akan"];
  if (region === "Greater Accra") return ["akan", "ewe"];
  return ["akan"];
}

function makeAgent(
  id: number,
  kind: AgentKind,
  name: string,
  region: string,
  rng: () => number,
  extras: Partial<Agent> = {},
): Agent {
  const angle = rng() * Math.PI * 2;
  const radius = 80 + rng() * 220;
  const knowledgeBase =
    kind === "producer"
      ? 0.45 + rng() * 0.4
      : kind === "intermediary"
        ? 0.2 + rng() * 0.25
        : 0.08 + rng() * 0.14;

  return {
    id,
    kind,
    name,
    region,
    x: Math.cos(angle) * radius,
    y: Math.sin(angle) * radius,
    vx: 0,
    vy: 0,
    knowledge: knowledgeBase,
    adopted: kind === "producer",
    compute: kind === "producer" ? 0.4 + rng() * 0.4 : rng() * 0.18,
    languages: languageForRegion(region),
    sector:
      kind === "intermediary"
        ? pick(rng, ["education", "hubs", "agriculture"])
        : kind === "user"
          ? pick(rng, ["farming", "community"])
          : "research",
    isHub: name === "UG HCI Lab" || name === "University of Ghana",
    ...extras,
  };
}

function addEdge(edges: Edge[], a: number, b: number, weight = 1) {
  if (a === b) return;
  const lo = Math.min(a, b);
  const hi = Math.max(a, b);
  if (edges.some((e) => e.a === lo && e.b === hi)) return;
  edges.push({ a: lo, b: hi, weight, cited: false });
}

export function createWorld(seed = 2026): World {
  const rng = mulberry32(seed);
  const agents: Agent[] = [];
  const edges: Edge[] = [];
  let id = 0;

  const hubSlots = [
    { x: 0, y: -40 },
    { x: -90, y: 50 },
    { x: 90, y: 50 },
  ];
  let hubI = 0;

  for (const name of UNI_NAMES) {
    const region = name.includes("HCI") || name === "University of Ghana" || name === "GTEC"
      ? "Greater Accra"
      : pick(rng, REGIONS);
    const isCore = name === "UG HCI Lab" || name === "University of Ghana" || name === "KNUST";
    const slot = isCore ? hubSlots[hubI++] : null;
    agents.push(
      makeAgent(id++, "producer", name, region, rng, {
        isHub: isCore,
        languages: [...LANGUAGES],
        knowledge: name === "UG HCI Lab" ? 0.92 : 0.62 + rng() * 0.2,
        compute: name === "UG HCI Lab" ? 0.85 : 0.45 + rng() * 0.25,
        ...(slot ? { x: slot.x, y: slot.y, vx: 0, vy: 0 } : {}),
      }),
    );
  }

  for (let i = 0; i < 8; i++) {
    agents.push(
      makeAgent(id++, "producer", `Industry partner ${i + 1}`, pick(rng, REGIONS), rng, {
        sector: pick(rng, ["telecom", "agritech", "fintech", "media"]),
      }),
    );
  }

  for (let i = 0; i < 22; i++) {
    const name = SME_NAMES[i % SME_NAMES.length]!;
    const suffix = i >= SME_NAMES.length ? ` ${Math.floor(i / SME_NAMES.length) + 1}` : "";
    agents.push(makeAgent(id++, "intermediary", `${name}${suffix}`, pick(rng, REGIONS), rng));
  }

  for (const name of TEACHER_NAMES) {
    agents.push(makeAgent(id++, "intermediary", name, pick(rng, REGIONS), rng));
  }

  for (let i = 0; i < 4; i++) {
    agents.push(
      makeAgent(id++, "intermediary", `District assembly ${i + 1}`, pick(rng, REGIONS), rng, {
        sector: "governance",
      }),
    );
  }

  for (let i = 0; i < 10; i++) {
    agents.push(
      makeAgent(id++, "user", `Language community ${i + 1}`, pick(rng, REGIONS), rng, {
        sector: "inclusion",
        languages: [pick(rng, LANGUAGES), pick(rng, LANGUAGES)],
      }),
    );
  }

  const n = agents.length;
  const k = 4;

  // Watts–Strogatz ring lattice + rewiring
  for (let i = 0; i < n; i++) {
    for (let j = 1; j <= k / 2; j++) {
      addEdge(edges, i, (i + j) % n, 0.6);
    }
  }
  for (const e of [...edges]) {
    if (chance(rng, 0.09)) {
      const target = Math.floor(rng() * n);
      e.b = target === e.a ? (target + 1) % n : target;
      if (e.a > e.b) {
        const tmp = e.a;
        e.a = e.b;
        e.b = tmp;
      }
    }
  }

  // Barabási–Albert preferential attachment onto hubs
  const hubs = agents.filter((a) => a.isHub || a.kind === "producer");
  for (const agent of agents) {
    if (agent.isHub) continue;
    const hub = pick(rng, hubs);
    addEdge(edges, agent.id, hub.id, 0.9);
    if (chance(rng, 0.25)) {
      addEdge(edges, agent.id, pick(rng, hubs).id, 0.5);
    }
  }

  // Extra local SME–teacher–community clustering
  const locals = agents.filter((a) => a.kind === "intermediary" || a.kind === "user");
  for (const a of locals) {
    const near = locals.filter((b) => b.region === a.region && b.id !== a.id);
    if (near.length && chance(rng, 0.55)) {
      addEdge(edges, a.id, pick(rng, near).id, 0.8);
    }
  }

  return {
    agents,
    edges,
    particles: [],
    events: [
      {
        tick: 0,
        text: "Synthetic hybrid network seeded — not a documented collaboration list.",
        source: "sim",
      },
    ],
    tick: 0,
    transfers: 0,
    nextParticle: 1,
    documented: false,
  };
}

export function neighbors(world: World, id: number): number[] {
  const out: number[] = [];
  for (const e of world.edges) {
    if (e.a === id) out.push(e.b);
    else if (e.b === id) out.push(e.a);
  }
  return out;
}

export function clusteringCoefficient(world: World): number {
  const { agents, edges } = world;
  const adj = new Map<number, Set<number>>();
  for (const a of agents) adj.set(a.id, new Set());
  for (const e of edges) {
    adj.get(e.a)?.add(e.b);
    adj.get(e.b)?.add(e.a);
  }
  let acc = 0;
  let counted = 0;
  for (const a of agents) {
    const nbrs = [...(adj.get(a.id) ?? [])];
    const d = nbrs.length;
    if (d < 2) continue;
    let triangles = 0;
    for (let i = 0; i < d; i++) {
      for (let j = i + 1; j < d; j++) {
        if (adj.get(nbrs[i]!)?.has(nbrs[j]!)) triangles++;
      }
    }
    acc += (2 * triangles) / (d * (d - 1));
    counted++;
  }
  return counted ? acc / counted : 0;
}

export function averagePathLength(world: World): number {
  const n = world.agents.length;
  if (n < 2) return 0;
  const adj = new Map<number, number[]>();
  for (const a of world.agents) adj.set(a.id, []);
  for (const e of world.edges) {
    adj.get(e.a)?.push(e.b);
    adj.get(e.b)?.push(e.a);
  }
  let total = 0;
  let pairs = 0;
  for (let s = 0; s < n; s++) {
    const start = world.agents[s]!.id;
    const dist = new Map<number, number>([[start, 0]]);
    const q = [start];
    while (q.length) {
      const cur = q.shift()!;
      const d = dist.get(cur)!;
      for (const nxt of adj.get(cur) ?? []) {
        if (!dist.has(nxt)) {
          dist.set(nxt, d + 1);
          q.push(nxt);
        }
      }
    }
    for (const d of dist.values()) {
      if (d > 0) {
        total += d;
        pairs++;
      }
    }
  }
  return pairs ? total / pairs : 0;
}
