import type { Agent } from "./types";

export type ClusterId = "waxal" | "nlp" | "rail" | "gov" | "bridge";

export const CLUSTER_LABEL: Record<ClusterId, string> = {
  waxal: "WAXAL / tɛkyerɛma pa",
  nlp: "GhanaNLP / Khaya",
  rail: "RAIL / KNUST",
  gov: "National AI Strategy",
  bridge: "Named in more than one programme",
};

const MEMBER: Record<string, ClusterId> = {
  "University of Ghana": "waxal",
  "UG HCI Lab": "waxal",
  "UCL GDI Hub": "waxal",
  "Makerere University": "waxal",
  "Digital Umuganda": "waxal",
  GhanaNLP: "nlp",
  "Khaya AI": "nlp",
  Algorine: "nlp",
  "University of Cape Coast": "nlp",
  "RAIL KNUST": "rail",
  KNUST: "rail",
  IDRC: "rail",
  Zindi: "rail",
  "MoFA / PPRSD": "rail",
  "Local farmers (PPRSD pilots)": "rail",
  "KNUST Disability Studies": "rail",
  MoCDTI: "gov",
  NITA: "gov",
  "Data Protection Commission": "gov",
  "Cyber Security Authority": "gov",
  "UNDP Ghana": "gov",
  UNESCO: "gov",
  Google: "bridge",
  "GIZ / DTC Ghana": "bridge",
};

export const CLUSTER_CENTRE: Record<ClusterId, { x: number; y: number }> = {
  waxal: { x: -168, y: -132 },
  nlp: { x: 168, y: -132 },
  rail: { x: -168, y: 132 },
  gov: { x: 168, y: 132 },
  bridge: { x: 0, y: 0 },
};

export const CLUSTER_BLURB: Record<ClusterId, string> = {
  waxal: "Admitted by UGSpeechData, WAXAL, or tɛkyerɛma pa (November 2024).",
  nlp: "Admitted by the GhanaNLP Parallel Corpora (arXiv:2603.13793) or the 2021 Khaya application.",
  rail: "Admitted by the KNUST KEEP grant (30 January 2022) or the crop-disease and inclusion record.",
  gov: "Admitted by the National AI Strategy, 24 April 2026 (moc.gov.gh).",
  bridge: "Named in more than one of those sources.",
};

export function clusterOf(name: string): ClusterId {
  return MEMBER[name] ?? "bridge";
}

export function placeClusters(agents: Agent[]): Agent[] {
  const buckets = new Map<ClusterId, Agent[]>();
  for (const a of agents) {
    const c = clusterOf(a.name);
    const list = buckets.get(c) ?? [];
    list.push(a);
    buckets.set(c, list);
  }
  return agents.map((a) => {
    const c = clusterOf(a.name);
    const group = buckets.get(c) ?? [a];
    const i = group.findIndex((x) => x.id === a.id);
    const n = group.length;
    const centre = CLUSTER_CENTRE[c];
    const radius = c === "bridge" ? 48 : 52 + Math.min(n, 6) * 4;
    const angle = (i / Math.max(1, n)) * Math.PI * 2 - Math.PI / 2;
    return {
      ...a,
      x: centre.x + Math.cos(angle) * radius,
      y: centre.y + Math.sin(angle) * radius,
    };
  });
}
