import { citedDegree } from "./insights";
import { componentOf } from "./paths";
import type { Agent, AgentKind, Language, World } from "./types";

export const ALL_YEARS = [2021, 2022, 2023, 2024, 2025, 2026] as const;

export type AppView = "network" | "analysis" | "languages" | "export" | "help";

export interface GraphFilters {
  searchTerm: string;
  roles: AgentKind[];
  showMain: boolean;
  showIsolated: boolean;
  minDegree: number;
  maxDegree: number;
  years: number[];
  language: Language | null;
}

export const DEFAULT_FILTERS: GraphFilters = {
  searchTerm: "",
  roles: ["producer", "intermediary", "user"],
  showMain: true,
  showIsolated: true,
  minDegree: 0,
  maxDegree: 12,
  years: [...ALL_YEARS],
  language: null,
};

export function mainComponentIds(world: World): Set<number> {
  let best = new Set<number>();
  const seen = new Set<number>();
  for (const a of world.agents) {
    if (seen.has(a.id)) continue;
    const c = componentOf(world, a.id, true);
    for (const id of c) seen.add(id);
    if (c.size > best.size) best = c;
  }
  return best;
}

export function edgeYear(date?: string): number | null {
  if (!date || !/^\d{4}/.test(date)) return null;
  return Number(date.slice(0, 4));
}

export function citedDeg(world: World, id: number) {
  return citedDegree(world, id);
}

export function agentVisible(world: World, agent: Agent, f: GraphFilters, main: Set<number>): boolean {
  if (!f.roles.includes(agent.kind)) return false;
  const isolated = !main.has(agent.id);
  if (isolated && !f.showIsolated) return false;
  if (!isolated && !f.showMain) return false;
  const d = citedDeg(world, agent.id);
  if (d < f.minDegree || d > f.maxDegree) return false;
  if (f.language && !agent.languages.includes(f.language)) return false;
  const q = f.searchTerm.trim().toLowerCase();
  if (q && !agent.name.toLowerCase().includes(q)) return false;
  return true;
}

export function edgeVisible(world: World, a: number, b: number, date: string | undefined, f: GraphFilters): boolean {
  const y = edgeYear(date);
  if (y != null && !f.years.includes(y)) return false;
  const main = mainComponentIds(world);
  const na = world.agents.find((x) => x.id === a);
  const nb = world.agents.find((x) => x.id === b);
  if (!na || !nb) return false;
  return agentVisible(world, na, f, main) && agentVisible(world, nb, f, main);
}

export function visibleIds(world: World, f: GraphFilters): Set<number> {
  const main = mainComponentIds(world);
  return new Set(world.agents.filter((a) => agentVisible(world, a, f, main)).map((a) => a.id));
}
