import type { Policy, ScenarioId } from "./types";

export interface Scenario {
  id: ScenarioId;
  title: string;
  blurb: string;
  policy: Policy;
}

export const SCENARIOS: Scenario[] = [
  {
    id: "baseline",
    title: "Baseline",
    blurb: "Fragmented status quo. Weak pipelines, scarce compute, little livelihood reach.",
    policy: { talent: 0.18, infra: 0.12, livelihood: 0.1, leadership: 0.15 },
  },
  {
    id: "talent",
    title: "Talent pipelines",
    blurb: "Long-term capability across universities, teacher colleges, labs, and industry.",
    policy: { talent: 0.86, infra: 0.28, livelihood: 0.22, leadership: 0.4 },
  },
  {
    id: "infra",
    title: "Shared infrastructure",
    blurb: "A national GPU / cloud hub hosted through universities and a public-private consortium.",
    policy: { talent: 0.32, infra: 0.9, livelihood: 0.2, leadership: 0.35 },
  },
  {
    id: "livelihood",
    title: "Livelihood problems",
    blurb: "Language AI for farmers, traders, teachers, assemblies, and accessibility.",
    policy: { talent: 0.35, infra: 0.3, livelihood: 0.92, leadership: 0.38 },
  },
  {
    id: "leadership",
    title: "Universities lead",
    blurb: "Faster accreditation, local frameworks, and universities shaping Ghanaian AI.",
    policy: { talent: 0.48, infra: 0.34, livelihood: 0.3, leadership: 0.9 },
  },
  {
    id: "integrated",
    title: "Integrated",
    blurb: "Talent, infrastructure, livelihood and leadership together — the primary comparison case.",
    policy: { talent: 0.78, infra: 0.74, livelihood: 0.8, leadership: 0.72 },
  },
];

export function scenarioById(id: ScenarioId) {
  return SCENARIOS.find((s) => s.id === id) ?? SCENARIOS[0]!;
}
