import { collaborationOf } from "./collaboration";
import { LANG_MARKS } from "./languageCoverage";
import { averagePathLength, clusteringCoefficient } from "./network";
import { articulationPoints, betweenness } from "./structure";
import { LANGUAGE_LABEL, LANGUAGES, type World } from "./types";

export function citedWorld(world: World): World {
  return { ...world, edges: world.edges.filter((e) => e.cited) };
}

export function componentCount(world: World): number {
  const adj = new Map<number, number[]>();
  for (const a of world.agents) adj.set(a.id, []);
  for (const e of world.edges) {
    if (!e.cited) continue;
    adj.get(e.a)?.push(e.b);
    adj.get(e.b)?.push(e.a);
  }
  const seen = new Set<number>();
  let n = 0;
  for (const a of world.agents) {
    if (seen.has(a.id)) continue;
    n += 1;
    const q = [a.id];
    seen.add(a.id);
    while (q.length) {
      const cur = q.shift()!;
      for (const nxt of adj.get(cur) ?? []) {
        if (seen.has(nxt)) continue;
        seen.add(nxt);
        q.push(nxt);
      }
    }
  }
  return n;
}

export function citedResults(world: World) {
  const cited = citedWorld(world);
  const degrees = world.agents.map((a) => ({
    id: a.id,
    name: a.name,
    d: cited.edges.filter((e) => e.a === a.id || e.b === a.id).length,
  }));
  const degVals = degrees.map((x) => x.d).sort((a, b) => a - b);
  const host = cited.edges.filter((e) => e.tie === "host").length;
  const project = cited.edges.length - host;
  const bc = betweenness(world);
  const ranked = [...bc.entries()]
    .map(([id, v]) => ({ name: world.agents.find((a) => a.id === id)?.name ?? String(id), v }))
    .sort((a, b) => b.v - a.v);
  const cuts = articulationPoints(world)
    .map((id) => world.agents.find((a) => a.id === id)?.name ?? String(id))
    .sort();

  const neighbourhoods = world.agents
    .map((a) => collaborationOf(world, a.id))
    .filter((c) => c.clustering != null && c.avgPath != null);
  const meanLocalC =
    neighbourhoods.reduce((s, c) => s + (c.clustering ?? 0), 0) / Math.max(1, neighbourhoods.length);
  const meanLocalL =
    neighbourhoods.reduce((s, c) => s + (c.avgPath ?? 0), 0) / Math.max(1, neighbourhoods.length);

  const langCounts = LANGUAGES.map((lang) => {
    const marks = LANG_MARKS.filter((m) => m.lang === lang);
    const orgs = [...new Set(marks.map((m) => m.org))];
    const source = marks[0]?.source ?? "";
    return { lang, label: LANGUAGE_LABEL[lang], n: orgs.length, orgs, source };
  });

  const dates = new Map<string, number>();
  const years = new Map<string, { n: number; sources: Set<string> }>();
  for (const e of cited.edges) {
    const k = e.date ?? "Date not stated";
    dates.set(k, (dates.get(k) ?? 0) + 1);
    const y = e.date && /^\d{4}/.test(e.date) ? e.date.slice(0, 4) : "Year not stated";
    const cur = years.get(y) ?? { n: 0, sources: new Set<string>() };
    cur.n += 1;
    if (e.source) cur.sources.add(e.source);
    years.set(y, cur);
  }

  return {
    n: world.agents.length,
    m: cited.edges.length,
    components: componentCount(world),
    host,
    project,
    degree: {
      min: degVals[0] ?? 0,
      median: degVals[Math.floor(degVals.length / 2)] ?? 0,
      max: degVals[degVals.length - 1] ?? 0,
      mean: degVals.length ? degVals.reduce((s, d) => s + d, 0) / degVals.length : 0,
      isolated: degrees.filter((x) => x.d === 0).map((x) => x.name),
      top: [...degrees].sort((a, b) => b.d - a.d).slice(0, 5),
    },
    globalC: clusteringCoefficient(cited),
    globalL: averagePathLength(cited),
    meanLocalC,
    meanLocalL,
    neighbourhoodsMeasured: neighbourhoods.length,
    betweenness: ranked.slice(0, 5),
    cuts,
    langCounts,
    chronology: [...dates.entries()].sort((a, b) => a[0].localeCompare(b[0])),
    years: [...years.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([year, v]) => ({ year, n: v.n, sources: [...v.sources] })),
    roles: {
      producer: world.agents.filter((a) => a.kind === "producer").length,
      intermediary: world.agents.filter((a) => a.kind === "intermediary").length,
      user: world.agents.filter((a) => a.kind === "user").length,
    },
  };
}
