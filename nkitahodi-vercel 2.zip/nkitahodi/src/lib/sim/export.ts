import { citeUrl } from "./citations";
import type { World } from "./types";
import { KIND_LABEL, LANGUAGE_LABEL } from "./types";

function csvEscape(v: string) {
  if (/[",\n]/.test(v)) return `"${v.replaceAll('"', '""')}"`;
  return v;
}

export function nodesCsv(world: World) {
  const header = ["id", "name", "role", "region", "sector", "languages", "cited_degree"];
  const rows = world.agents.map((a) => {
    const deg = world.edges.filter((e) => e.cited && (e.a === a.id || e.b === a.id)).length;
    return [
      String(a.id),
      a.name,
      KIND_LABEL[a.kind],
      a.region,
      a.sector,
      a.languages.map((l) => LANGUAGE_LABEL[l]).join("; "),
      String(deg),
    ].map(csvEscape);
  });
  return [header, ...rows].map((r) => r.join(",")).join("\n");
}

export function edgesCsv(world: World) {
  const header = ["source", "target", "date", "evidence", "source_label", "url"];
  const rows = world.edges
    .filter((e) => e.cited)
    .map((e) => {
      const a = world.agents.find((x) => x.id === e.a);
      const b = world.agents.find((x) => x.id === e.b);
      return [
        a?.name ?? "",
        b?.name ?? "",
        e.date ?? "",
        e.evidence ?? "",
        e.source ?? "",
        e.href ?? citeUrl(e.source) ?? "",
      ].map(csvEscape);
    });
  return [header, ...rows].map((r) => r.join(",")).join("\n");
}

export function methodsNote(world: World) {
  return [
    "Nkitahodi — construction of the public graph",
    "",
    "Admission rule. An organisation or link is included only if both endpoints are named in a peer-reviewed paper, an official laboratory or ministry publication, a documented grant award, or the National Artificial Intelligence Strategy of 24 April 2026.",
    "",
    `Inventory. ${world.agents.length} organisations; ${world.edges.filter((e) => e.cited).length} cited links. No synthetic vertices or links are generated.`,
    "",
    "Roles. Producers generate or finance language resources and models. Intermediates deploy those outputs. Users are named communities or offices of intended adoption. Classification follows the admitting source.",
    "",
    "Languages. Akan, Ewe, Dagbani, Dagaare and Ikposo follow UGSpeechData, WAXAL and tɛkyerɛma pa (speech). Ga, Fante and Kusaal follow the GhanaNLP parallel corpora (text). Hausa appears on the continental WAXAL list and is not a University of Ghana collection mark.",
    "",
    "Metrics. The clustering coefficient is mean local transitivity (Watts and Strogatz, 1998). Mean geodesic distance is the average shortest-path length over reachable pairs. Betweenness follows Brandes (2001). Articulation points are vertices whose deletion increases the number of components. These quantities are structural; they are not estimates of adoption.",
    "",
    "Dates. Link dates are the publication or announcement date of the admitting source, not the inferred start of collaboration.",
    "",
    "Geography. The same cited links are arranged by recorded location. Outside Ghana denotes partners named extra-territorially in those sources.",
  ].join("\n");
}

export function downloadText(filename: string, text: string, type = "text/plain") {
  const blob = new Blob([text], { type: `${type};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function graphMl(world: World) {
  const nodes = world.agents
    .map((a) => {
      const deg = world.edges.filter((e) => e.cited && (e.a === a.id || e.b === a.id)).length;
      return `    <node id="n${a.id}">
      <data key="label">${escapeXml(a.name)}</data>
      <data key="role">${a.kind}</data>
      <data key="degree">${deg}</data>
    </node>`;
    })
    .join("\n");
  const edges = world.edges
    .filter((e) => e.cited)
    .map(
      (e, i) => `    <edge id="e${i}" source="n${e.a}" target="n${e.b}">
      <data key="type">${e.tie ?? "project"}</data>
      <data key="year">${e.date ?? ""}</data>
    </edge>`,
    )
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>
<graphml xmlns="http://graphml.graphdrawing.org/xmlns">
  <key id="label" for="node" attr.name="label" attr.type="string"/>
  <key id="role" for="node" attr.name="role" attr.type="string"/>
  <key id="degree" for="node" attr.name="degree" attr.type="int"/>
  <key id="type" for="edge" attr.name="type" attr.type="string"/>
  <key id="year" for="edge" attr.name="year" attr.type="string"/>
  <graph id="G" edgedefault="undirected">
${nodes}
${edges}
  </graph>
</graphml>`;
}

export function networkJson(world: World) {
  return JSON.stringify(
    {
      title: "A documentary network of collaboration among Ghanaian language-technology organisations, 2021–2026",
      nodes: world.agents.map((a) => ({
        id: a.id,
        name: a.name,
        role: a.kind,
        region: a.region,
        sector: a.sector,
        languages: a.languages,
        note: a.note ?? "",
      })),
      edges: world.edges
        .filter((e) => e.cited)
        .map((e) => ({
          source: e.a,
          target: e.b,
          tie: e.tie ?? "project",
          date: e.date ?? "",
          evidence: e.evidence ?? "",
          source_label: e.source ?? "",
          href: e.href ?? "",
        })),
    },
    null,
    2,
  );
}

function escapeXml(s: string) {
  const amp = String.fromCharCode(38);
  const lt = String.fromCharCode(60);
  const gt = String.fromCharCode(62);
  const quot = String.fromCharCode(34);
  return s
    .split(amp)
    .join(`${amp}amp;`)
    .split(lt)
    .join(`${amp}lt;`)
    .split(gt)
    .join(`${amp}gt;`)
    .split(quot)
    .join(`${amp}quot;`);
}
