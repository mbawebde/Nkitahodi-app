import type { Language } from "./types";

export interface LangMark {
  org: string;
  lang: Language;
  evidence: string;
  source: string;
}

const WAXAL_FIVE: Language[] = ["akan", "ewe", "dagbani", "dagaare", "ikposo"];
const NLP_FIVE: Language[] = ["akan", "ewe", "ga", "fante", "kusaal"];

function marks(orgs: string[], langs: Language[], evidence: string, source: string): LangMark[] {
  const out: LangMark[] = [];
  for (const org of orgs) {
    for (const lang of langs) out.push({ org, lang, evidence, source });
  }
  return out;
}

export const LANG_MARKS: LangMark[] = [
  ...marks(
    ["University of Ghana", "UG HCI Lab"],
    WAXAL_FIVE,
    "UGSpeechData / WAXAL: approximately 5,000 hours of Akan, Ewe, Dagbani, Dagaare and Ikposo.",
    "doi:10.57760/sciencedb.22298",
  ),
  ...marks(
    ["University of Ghana", "UG HCI Lab", "Google", "UCL GDI Hub"],
    WAXAL_FIVE,
    "tɛkyerɛma pa (1 Nov 2024) names the same five Ghanaian languages for non-standard-speech ASR.",
    "disabilityinnovation.com 1 Nov 2024",
  ),
  ...marks(
    ["University of Ghana", "Google"],
    WAXAL_FIVE,
    "Google Research WAXAL blog: UG collected ASR and TTS for Ghanaian languages in the consortium.",
    "research.google/blog/waxal",
  ),
  ...marks(
    ["GhanaNLP", "Khaya AI", "Algorine", "University of Cape Coast"],
    NLP_FIVE,
    "GhanaNLP Parallel Corpora document Twi, Fante, Ewe, Ga and Kusaal (arXiv:2603.13793).",
    "arXiv:2603.13793",
  ),
  ...marks(
    ["GhanaNLP", "Algorine", "Khaya AI"],
    NLP_FIVE,
    "Khaya Translator Web App (13 Jul 2021), Algorine and GhanaNLP: first Ghanaian-language ML translation application.",
    "ghananlp.org/project/translator-webapp",
  ),
  ...marks(
    ["Google"],
    NLP_FIVE,
    "arXiv:2603.13793 funding statement: Google LLC provided single-source support to the GhanaNLP volunteer group.",
    "arXiv:2603.13793",
  ),
  ...marks(
    ["Khaya AI", "GhanaNLP"],
    ["dagbani"],
    "Khaya product documentation lists Dagbani among supported translation and ASR languages.",
    "khaya.ai/features/machine-translation",
  ),
  ...marks(
    ["Khaya AI", "GhanaNLP"],
    ["gurene"],
    "Khaya lists Gurene (Farefare / Frafra) as a supported Ghanaian translation language.",
    "khaya.ai/features/machine-translation",
  ),
  ...marks(
    ["Google"],
    ["fante", "hausa"],
    "WAXAL language list (Google Africa, 2 Feb 2026) includes Fante and Hausa among 21 African languages. The list does not assign collection of Hausa to the University of Ghana.",
    "blog.google WAXAL 2 Feb 2026",
  ),
];

export function languagesOf(org: string): Language[] {
  return [...new Set(LANG_MARKS.filter((m) => m.org === org).map((m) => m.lang))];
}

export function marksFor(org: string, lang: Language): LangMark[] {
  return LANG_MARKS.filter((m) => m.org === org && m.lang === lang);
}
