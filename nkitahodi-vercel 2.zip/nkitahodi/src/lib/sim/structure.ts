import type { World } from "./types";

function adjacency(world: World) {
  const adj = new Map<number, number[]>();
  for (const a of world.agents) adj.set(a.id, []);
  for (const e of world.edges) {
    if (!e.cited) continue;
    adj.get(e.a)?.push(e.b);
    adj.get(e.b)?.push(e.a);
  }
  return adj;
}

/** Brandes (2001), undirected unweighted betweenness. */
export function betweenness(world: World): Map<number, number> {
  const nodes = world.agents.map((a) => a.id);
  const adj = adjacency(world);
  const cb = new Map<number, number>(nodes.map((id) => [id, 0]));

  for (const s of nodes) {
    const stack: number[] = [];
    const pred = new Map<number, number[]>(nodes.map((v) => [v, []]));
    const sigma = new Map<number, number>(nodes.map((v) => [v, 0]));
    const dist = new Map<number, number>(nodes.map((v) => [v, -1]));
    sigma.set(s, 1);
    dist.set(s, 0);
    const q = [s];
    while (q.length) {
      const v = q.shift()!;
      stack.push(v);
      for (const w of adj.get(v) ?? []) {
        if (dist.get(w) === -1) {
          dist.set(w, dist.get(v)! + 1);
          q.push(w);
        }
        if (dist.get(w) === dist.get(v)! + 1) {
          sigma.set(w, sigma.get(w)! + sigma.get(v)!);
          pred.get(w)!.push(v);
        }
      }
    }
    const delta = new Map<number, number>(nodes.map((v) => [v, 0]));
    while (stack.length) {
      const w = stack.pop()!;
      for (const v of pred.get(w)!) {
        const add = (sigma.get(v)! / sigma.get(w)!) * (1 + delta.get(w)!);
        delta.set(v, delta.get(v)! + add);
      }
      if (w !== s) cb.set(w, cb.get(w)! + delta.get(w)!);
    }
  }
  for (const [k, v] of cb) cb.set(k, v / 2);
  return cb;
}

export function articulationPoints(world: World): number[] {
  const adj = adjacency(world);
  const nodes = world.agents.map((a) => a.id);
  const disc = new Map<number, number>();
  const low = new Map<number, number>();
  const parent = new Map<number, number | null>();
  const ap = new Set<number>();
  let time = 0;

  const dfs = (u: number) => {
    disc.set(u, time);
    low.set(u, time);
    time += 1;
    let children = 0;
    for (const v of adj.get(u) ?? []) {
      if (!disc.has(v)) {
        children += 1;
        parent.set(v, u);
        dfs(v);
        low.set(u, Math.min(low.get(u)!, low.get(v)!));
        if (parent.get(u) == null && children > 1) ap.add(u);
        if (parent.get(u) != null && low.get(v)! >= disc.get(u)!) ap.add(u);
      } else if (v !== parent.get(u)) {
        low.set(u, Math.min(low.get(u)!, disc.get(v)!));
      }
    }
  };

  for (const u of nodes) {
    if (!disc.has(u)) {
      parent.set(u, null);
      dfs(u);
    }
  }
  return [...ap];
}

export function bridges(world: World): { a: number; b: number }[] {
  const adj = adjacency(world);
  const disc = new Map<number, number>();
  const low = new Map<number, number>();
  const parent = new Map<number, number | null>();
  const found: { a: number; b: number }[] = [];
  let time = 0;

  const dfs = (u: number) => {
    disc.set(u, time);
    low.set(u, time);
    time += 1;
    for (const v of adj.get(u) ?? []) {
      if (!disc.has(v)) {
        parent.set(v, u);
        dfs(v);
        low.set(u, Math.min(low.get(u)!, low.get(v)!));
        if (low.get(v)! > disc.get(u)!) found.push({ a: u, b: v });
      } else if (v !== parent.get(u)) {
        low.set(u, Math.min(low.get(u)!, disc.get(v)!));
      }
    }
  };

  for (const a of world.agents) {
    if (!disc.has(a.id)) {
      parent.set(a.id, null);
      dfs(a.id);
    }
  }
  return found;
}
