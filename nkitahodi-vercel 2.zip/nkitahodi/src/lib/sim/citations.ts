const RULES: { test: RegExp; href: string }[] = [
  { test: /arxiv:2603\.13793/i, href: "https://arxiv.org/abs/2603.13793" },
  { test: /sciencedb\.22298|10\.57760/i, href: "https://doi.org/10.57760/sciencedb.22298" },
  { test: /research\.google\/blog\/waxal|waxal/i, href: "https://research.google/blog/waxal-a-large-scale-open-resource-for-african-language-speech-technology/" },
  { test: /blog\.google waxal/i, href: "https://blog.google/intl/en-africa/company-news/outreach-and-initiatives/introducing-waxal-a-new-open-dataset-for-african-speech-technology/" },
  { test: /khaya\.ai\/features|machine-translation/i, href: "https://www.khaya.ai/features/machine-translation" },
  { test: /khaya\.ai/i, href: "https://www.khaya.ai/about-us" },
  { test: /ghananlp\.org\/project/i, href: "https://ghananlp.org/project/translator-webapp/" },
  { test: /rail\.knust/i, href: "https://rail.knust.edu.gh/" },
  { test: /ai4d\.ai rail|rail impact/i, href: "https://www.ai4d.ai/blog/driving-responsible-ai-innovation-rail-s-impact-under-ai4d" },
  { test: /idrc-crdi|ai4d\.ai \//i, href: "https://idrc-crdi.ca/en/initiative/artificial-intelligence-development" },
  { test: /bmz-digital/i, href: "https://www.bmz-digital.global/en/news/ghanas-rail-lab-where-ai-talent-grows/" },
  { test: /moc\.gov\.gh/i, href: "https://moc.gov.gh/2026/04/24/ghana-launches-national-ai-strategy-to-drive-digital-transformation-and-economic-growth/" },
  {
    test: /disabilityinnovation|gdi hub/i,
    href: "https://www.disabilityinnovation.com/news/google-university-of-ghana-and-gdi-hub-to-expand-ai-powered-speech-recognition-for-non-standard-speech-in-ghanaian-languages",
  },
  { test: /hci-lab-ugspeechdata|github\.com\/hci/i, href: "https://github.com/HCI-LAB-UGSPEECHDATA" },
  { test: /keep\.knust\.edu\.gh/i, href: "https://keep.knust.edu.gh/news/cad-1-million-grant-has-been-awarded-college-engineering-establish-multidisciplinary" },
];

export function citeUrl(source?: string): string | undefined {
  if (!source) return undefined;
  for (const rule of RULES) {
    if (rule.test.test(source)) return rule.href;
  }
  return undefined;
}
