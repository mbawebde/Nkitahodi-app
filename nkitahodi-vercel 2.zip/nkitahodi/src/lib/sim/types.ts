export type AgentKind = "producer" | "intermediary" | "user";

export type Language =
  | "akan"
  | "ewe"
  | "dagbani"
  | "dagaare"
  | "ikposo"
  | "ga"
  | "fante"
  | "kusaal"
  | "hausa"
  | "gurene";

export const LANGUAGES: Language[] = [
  "akan",
  "ewe",
  "dagbani",
  "dagaare",
  "ikposo",
  "ga",
  "fante",
  "kusaal",
  "gurene",
  "hausa",
];

export const LANGUAGE_LABEL: Record<Language, string> = {
  akan: "Akan / Twi",
  ewe: "Ewe",
  dagbani: "Dagbani",
  dagaare: "Dagaare",
  ikposo: "Ikposo",
  ga: "Ga",
  fante: "Fante",
  kusaal: "Kusaal",
  gurene: "Gurene",
  hausa: "Hausa",
};

/** Relative data-availability proxies (UGSpeechData / WAXAL style). Not measured WER. */
export const LANGUAGE_DATA_PROXY: Record<Language, number> = {
  akan: 0.72,
  ewe: 0.58,
  dagbani: 0.48,
  dagaare: 0.42,
  ikposo: 0.38,
  ga: 0.4,
  fante: 0.45,
  kusaal: 0.3,
  gurene: 0.28,
  hausa: 0.35,
};

export const KIND_LABEL: Record<AgentKind, string> = {
  producer: "Producer",
  intermediary: "Intermediate",
  user: "User",
};

export type GraphMode = "documented" | "synthetic";

export interface Agent {
  id: number;
  kind: AgentKind;
  name: string;
  region: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  knowledge: number;
  adopted: boolean;
  compute: number;
  languages: Language[];
  sector: string;
  isHub: boolean;
  note?: string;
  accessibility?: boolean;
}

export interface Edge {
  a: number;
  b: number;
  weight: number;
  evidence?: string;
  source?: string;
  href?: string;
  date?: string;
  tie?: "host" | "project";
  cited: boolean;
  replaced?: {
    a: number;
    b: number;
    evidence?: string;
    source?: string;
    href?: string;
  };
}

export interface RewirePoint {
  x: number;
  clustering: number;
  avgPath: number;
}

export interface RewireReport {
  kept: string;
  dropped: string;
  joined: string;
  citation?: string;
  source?: string;
}

export interface Particle {
  id: number;
  a: number;
  b: number;
  t: number;
  kind: "knowledge" | "adopt";
}

export interface Policy {
  talent: number;
  infra: number;
  livelihood: number;
  leadership: number;
}

export interface ModelQuality {
  akan: number;
  ewe: number;
  dagbani: number;
  dagaare: number;
  ikposo: number;
  ga: number;
  fante: number;
  kusaal: number;
  gurene: number;
  hausa: number;
}

export interface Metrics {
  tick: number;
  clustering: number;
  avgPath: number;
  adoption: number;
  intermediaryAdoption: number;
  userAdoption: number;
  knowledge: number;
  modelQuality: ModelQuality;
  avgQuality: number;
  livelihoodImpact: number;
  hubs: number;
  transfers: number;
}

export interface SimEvent {
  tick: number;
  text: string;
  source?: "cited" | "sim";
  evidence?: string;
  orgIds?: number[];
}

export interface World {
  agents: Agent[];
  edges: Edge[];
  particles: Particle[];
  events: SimEvent[];
  tick: number;
  transfers: number;
  nextParticle: number;
  documented: boolean;
}

export type ScenarioId =
  | "baseline"
  | "integrated"
  | "talent"
  | "infra"
  | "livelihood"
  | "leadership";

export const PRIMARY_SCENARIOS: ScenarioId[] = ["baseline", "integrated"];
