import { clamp } from "../utils";
import { averagePathLength, clusteringCoefficient } from "./network";
import { chance, mulberry32, pick } from "./rng";
import type { Language, Metrics, ModelQuality, Policy, World } from "./types";
import { LANGUAGE_DATA_PROXY, LANGUAGES } from "./types";

function languageQuality(world: World): ModelQuality {
  const quality = { ...LANGUAGE_DATA_PROXY };
  for (const lang of LANGUAGES) {
    const holders = world.agents.filter((a) => a.languages.includes(lang));
    if (!holders.length) {
      quality[lang] = LANGUAGE_DATA_PROXY[lang] * 0.5;
      continue;
    }
    const k = holders.reduce((s, a) => s + a.knowledge, 0) / holders.length;
    const c = holders.reduce((s, a) => s + a.compute, 0) / holders.length;
    quality[lang] = clamp(0.4 * LANGUAGE_DATA_PROXY[lang] + 0.4 * k + 0.2 * c, 0, 1);
  }
  return quality;
}

export function computeMetrics(world: World): Metrics {
  const { agents } = world;
  const n = agents.length || 1;
  const knowledge = agents.reduce((s, a) => s + a.knowledge, 0) / n;
  const hubs = agents.filter((a) => a.isHub).length;
  const modelQuality = languageQuality(world);
  const avgQuality = Object.values(modelQuality).reduce((s, v) => s + v, 0) / LANGUAGES.length;

  const inter = agents.filter((a) => a.kind === "intermediary");
  const users = agents.filter((a) => a.kind === "user");
  const adoptable = agents.filter((a) => a.kind !== "producer");

  const livelihoodAgents = [...inter, ...users];
  const livelihoodImpact =
    livelihoodAgents.reduce((s, a) => s + (a.adopted ? a.knowledge : a.knowledge * 0.25), 0) /
    Math.max(1, livelihoodAgents.length);

  return {
    tick: world.tick,
    clustering: clusteringCoefficient(world),
    avgPath: averagePathLength(world),
    adoption: adoptable.length
      ? adoptable.filter((a) => a.adopted).length / adoptable.length
      : 0,
    intermediaryAdoption: inter.length
      ? inter.filter((a) => a.adopted).length / inter.length
      : 0,
    userAdoption: users.length ? users.filter((a) => a.adopted).length / users.length : 0,
    knowledge,
    modelQuality,
    avgQuality,
    livelihoodImpact,
    hubs,
    transfers: world.transfers,
  };
}

export function tickWorld(world: World, policy: Policy, seedBoost = 0): World {
  const rng = mulberry32(2026 + world.tick * 997 + seedBoost);
  const agents = world.agents.map((a) => ({ ...a }));
  const byId = new Map(agents.map((a) => [a.id, a]));
  const events = world.events.slice(0, 48);
  const particles = world.particles
    .map((p) => ({ ...p, t: p.t + 0.08 }))
    .filter((p) => p.t < 1);
  let transfers = world.transfers;
  let nextParticle = world.nextParticle;

  const learningRate = 0.08 + policy.talent * 0.12;
  const infraBoost = policy.infra;
  const liveBoost = policy.livelihood;

  // Producers improve models
  for (const a of agents) {
    if (a.kind === "producer") {
      a.compute = clamp(a.compute + 0.02 * infraBoost, 0, 1);
      a.knowledge = clamp(a.knowledge + learningRate * 0.04 + a.compute * 0.01, 0, 1);
    }
  }

  // Knowledge transfer along cited edges
  for (const e of world.edges) {
    const a = byId.get(e.a);
    const b = byId.get(e.b);
    if (!a || !b) continue;
    const hi = a.knowledge >= b.knowledge ? a : b;
    const lo = hi === a ? b : a;
    const gap = hi.knowledge - lo.knowledge;
    if (gap < 0.04) continue;
    const shareLang = hi.languages.some((l) => lo.languages.includes(l));
    const rate = lo.kind === "producer" ? learningRate : learningRate * 0.6;
    const p =
      0.1 +
      e.weight * 0.14 +
      (hi.isHub ? 0.12 : 0) +
      (shareLang ? 0.08 : 0) +
      policy.talent * 0.22 +
      policy.leadership * 0.08;
    if (!chance(rng, p)) continue;
    lo.knowledge = clamp(lo.knowledge + gap * (0.08 + hi.compute * 0.1) * (rate / 0.12), 0, 1);
    transfers++;
    if (particles.length < 28) {
      particles.push({ id: nextParticle++, a: hi.id, b: lo.id, t: 0, kind: "knowledge" });
    }
    if (chance(rng, 0.08)) {
      events.unshift({
        tick: world.tick + 1,
        text: `Simulated hop: ${hi.name} → ${lo.name}`,
        source: "sim",
        evidence: e.evidence,
        orgIds: [hi.id, lo.id],
      });
    }
  }

  const producerQ =
    agents
      .filter((a) => a.kind === "producer")
      .reduce((s, a) => s + a.knowledge * (0.5 + 0.5 * a.compute), 0) /
    Math.max(1, agents.filter((a) => a.kind === "producer").length);

  // Intermediaries adopt when quality + knowledge pass a threshold
  for (const a of agents) {
    if (a.kind !== "intermediary" || a.adopted) continue;
    const utility = 0.7 * producerQ + 0.3 * a.knowledge;
    const threshold = 0.55 - 0.15 * liveBoost;
    if (utility > threshold && chance(rng, 0.22 + liveBoost * 0.45 + policy.infra * 0.12)) {
      a.adopted = true;
      particles.push({ id: nextParticle++, a: a.id, b: a.id, t: 0, kind: "adopt" });
      events.unshift({
        tick: world.tick + 1,
        text: `Simulated adoption: ${a.name} began deploying a Ghanaian-language tool.`,
        source: "sim",
        orgIds: [a.id],
      });
    }
  }

  // Users adopt via peer effect
  for (const a of agents) {
    if (a.kind !== "user" || a.adopted) continue;
    const nbrs = world.edges
      .filter((e) => e.a === a.id || e.b === a.id)
      .map((e) => byId.get(e.a === a.id ? e.b : e.a))
      .filter(Boolean);
    const peer = nbrs.some((n) => n!.adopted);
    let p = 0.14 + 0.42 * liveBoost + 0.1 * policy.talent;
    if (a.accessibility) p *= producerQ < 0.5 ? 0.7 : 1.1;
    if (peer && chance(rng, p)) {
      a.adopted = true;
      particles.push({ id: nextParticle++, a: a.id, b: a.id, t: 0, kind: "adopt" });
      events.unshift({
        tick: world.tick + 1,
        text: `Simulated adoption: ${a.name} adopted a Ghanaian-language tool.`,
        source: "sim",
        orgIds: [a.id],
      });
    }
  }

  // New edges only on the synthetic graph
  const newEdges = [...world.edges];
  if (!world.documented && policy.leadership > 0.45 && chance(rng, 0.18 + policy.leadership * 0.2)) {
    const producers = agents.filter((a) => a.kind === "producer");
    const periphery = agents.filter((a) => a.kind !== "producer");
    if (producers.length && periphery.length) {
      const u = pick(rng, producers);
      const p = pick(rng, periphery);
      const exists = newEdges.some(
        (e) => (e.a === u.id && e.b === p.id) || (e.a === p.id && e.b === u.id),
      );
      if (!exists) {
        newEdges.push({
          a: Math.min(u.id, p.id),
          b: Math.max(u.id, p.id),
          weight: 0.7,
          cited: false,
        });
        events.unshift({
          tick: world.tick + 1,
          text: `Simulated new thread: ${u.name} ↔ ${p.name} (what-if, not cited).`,
          source: "sim",
          orgIds: [u.id, p.id],
        });
      }
    }
  }

  return {
    agents,
    edges: newEdges,
    particles,
    events: events.slice(0, 40),
    tick: world.tick + 1,
    transfers,
    nextParticle,
    documented: world.documented,
  };
}

export function languageCoverage(quality: ModelQuality): { lang: Language; value: number }[] {
  return LANGUAGES.map((lang) => ({ lang, value: quality[lang] }));
}

export function robustnessDrop(world: World): number {
  const degrees = new Map<number, number>();
  for (const a of world.agents) degrees.set(a.id, 0);
  for (const e of world.edges) {
    degrees.set(e.a, (degrees.get(e.a) ?? 0) + 1);
    degrees.set(e.b, (degrees.get(e.b) ?? 0) + 1);
  }
  let top = world.agents[0]?.id ?? 0;
  let best = -1;
  for (const [id, d] of degrees) {
    if (d > best) {
      best = d;
      top = id;
    }
  }
  const remaining = world.edges.filter((e) => e.a !== top && e.b !== top).length;
  return 1 - remaining / Math.max(1, world.edges.length);
}
