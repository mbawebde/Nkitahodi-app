import type { Agent, AgentKind, World } from "./types";

export function neighborsOf(world: World, id: number, citedOnly = false): Agent[] {
  const ids = new Set<number>();
  for (const e of world.edges) {
    if (citedOnly && !e.cited) continue;
    if (e.a === id) ids.add(e.b);
    if (e.b === id) ids.add(e.a);
  }
  return world.agents.filter((a) => ids.has(a.id));
}

export function citedDegree(world: World, id: number) {
  return world.edges.filter((e) => e.cited && (e.a === id || e.b === id)).length;
}

export function hopsToKind(world: World, start: number, kind: AgentKind): number | null {
  const adj = new Map<number, number[]>();
  for (const a of world.agents) adj.set(a.id, []);
  for (const e of world.edges) {
    if (!e.cited) continue;
    adj.get(e.a)?.push(e.b);
    adj.get(e.b)?.push(e.a);
  }
  const dist = new Map<number, number>([[start, 0]]);
  const q = [start];
  while (q.length) {
    const cur = q.shift()!;
    const d = dist.get(cur)!;
    const agent = world.agents.find((a) => a.id === cur);
    if (cur !== start && agent?.kind === kind) return d;
    for (const nxt of adj.get(cur) ?? []) {
      if (!dist.has(nxt)) {
        dist.set(nxt, d + 1);
        q.push(nxt);
      }
    }
  }
  return null;
}

export function explainCluster(clustering: number | null, avgPath: number | null, size: number, threads: number) {
  if (size < 3 || clustering == null) {
    return "The clustering coefficient is undefined for fewer than three organisations, because a closed triad cannot form. The neighbourhood is reported, but transitivity is not computed.";
  }
  const cluster =
    clustering >= 0.6
      ? `The cited neighbourhood comprises ${size} organisations. Local clustering of ${clustering.toFixed(2)} indicates that most adjacent pairs are themselves linked: the neighbourhood is densely closed.`
      : clustering > 0
        ? `The cited neighbourhood comprises ${size} organisations. Local clustering of ${clustering.toFixed(2)} indicates partial closure: some adjacent pairs are linked; others meet only through the selected organisation.`
        : `The ${size - 1} adjacent organisations are mutually unconnected. All documented ties in this neighbourhood are incident to the selected organisation (clustering coefficient 0).`;
  const walk =
    avgPath == null
      ? ""
      : ` Mean geodesic distance is ${avgPath.toFixed(2)} across ${threads} cited link${threads === 1 ? "" : "s"}: the typical number of steps between members of this neighbourhood.`;
  return cluster + walk;
}

export function gapLine(agent: Agent, nbrs: Agent[]) {
  const inter = nbrs.filter((a) => a.kind === "intermediary");
  const users = nbrs.filter((a) => a.kind === "user");
  const producers = nbrs.filter((a) => a.kind === "producer");
  if (agent.kind === "producer") {
    if (!inter.length && !users.length) {
      return "Every cited neighbour is a producer. No intermediate or named user organisation is adjacent on this record. Knowledge is created or financed, but the public path does not yet name a deploying or end-user organisation.";
    }
    if (users.length && !inter.length) {
      return "A named user organisation is adjacent. No intermediate lies on the documented path between this producer and that user.";
    }
    return null;
  }
  if (agent.kind === "intermediary") {
    if (!producers.length) return "No cited producer is adjacent on this record.";
    if (!users.length) return "A producer is adjacent; no named user organisation is.";
    return "The organisation is adjacent to both a producer and a user on the public record, and therefore occupies a translating position.";
  }
  if (!producers.length) return "No cited path from a producer to this user organisation is present on the public record.";
  return null;
}
