import type { Agent, World } from "./types";

export type GeoZone = "accra" | "ashanti" | "central" | "abroad";

export const GEO_ZONES: GeoZone[] = ["accra", "ashanti", "central", "abroad"];

export const GEO_LABEL: Record<GeoZone, string> = {
  accra: "Greater Accra",
  ashanti: "Ashanti",
  central: "Central",
  abroad: "Outside Ghana",
};

export const GEO_BLURB: Record<GeoZone, string> = {
  accra: "Named as Greater Accra.",
  ashanti: "Named as Ashanti.",
  central: "Named as Central.",
  abroad: "Named outside Ghana.",
};

export function zoneOf(agent: Agent): GeoZone {
  if (agent.region === "Greater Accra") return "accra";
  if (agent.region === "Ashanti") return "ashanti";
  if (agent.region === "Central") return "central";
  return "abroad";
}

export function zoneCounts(world: World) {
  const counts: Record<GeoZone, number> = { accra: 0, ashanti: 0, central: 0, abroad: 0 };
  for (const a of world.agents) counts[zoneOf(a)]++;
  return counts;
}

export function zoneFlows(world: World) {
  const pairs: { a: GeoZone; b: GeoZone; n: number }[] = [];
  const key = (x: GeoZone, y: GeoZone) => (x < y ? `${x}|${y}` : `${y}|${x}`);
  const map = new Map<string, { a: GeoZone; b: GeoZone; n: number }>();
  for (const e of world.edges) {
    if (!e.cited) continue;
    const aa = world.agents.find((x) => x.id === e.a);
    const bb = world.agents.find((x) => x.id === e.b);
    if (!aa || !bb) continue;
    const za = zoneOf(aa);
    const zb = zoneOf(bb);
    if (za === zb) continue;
    const k = key(za, zb);
    const cur = map.get(k) ?? { a: za < zb ? za : zb, b: za < zb ? zb : za, n: 0 };
    cur.n += 1;
    map.set(k, cur);
  }
  for (const v of map.values()) pairs.push(v);
  return pairs.sort((x, y) => y.n - x.n);
}

export function placeGeo(agents: Agent[]): Map<number, { x: number; y: number }> {
  const centres: Record<GeoZone, { x: number; y: number }> = {
    accra: { x: -120, y: -20 },
    ashanti: { x: 40, y: 90 },
    central: { x: -40, y: 110 },
    abroad: { x: 140, y: -70 },
  };
  const buckets = new Map<GeoZone, Agent[]>();
  for (const a of agents) {
    const z = zoneOf(a);
    const list = buckets.get(z) ?? [];
    list.push(a);
    buckets.set(z, list);
  }
  const pos = new Map<number, { x: number; y: number }>();
  for (const z of GEO_ZONES) {
    const group = buckets.get(z) ?? [];
    const c = centres[z];
    group.forEach((a, i) => {
      const n = Math.max(1, group.length);
      const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
      const radius = 28 + Math.min(n, 8) * 6;
      pos.set(a.id, { x: c.x + Math.cos(angle) * radius, y: c.y + Math.sin(angle) * radius });
    });
  }
  return pos;
}
